<center><h1>Test de la liste des verbes conjugu�s des trois groupes</h1></center>
<?php

require_once("List/listeVerbe.php");

require_once("Class/class.verbe.premierGroupe.php");
require_once("Class/class.verbe.deuxiemeGroupe.php");
require_once("Class/class.verbe.troisiemeGroupe.php");

$objetPremierGroupe = new verbePremierGroupe($listeVerbe['premierGroupe']);
$objetDeuxiemeGroupe = new verbeDeuxiemeGroupe($listeVerbe['deuxiemeGroupe']);
$objetTroisiemeGroupe= new verbeTroisiemeGroupe($listeVerbe['troisiemeGroupe']);

echo "<h2>Premier groupe : </h2>";
$premierGroupe = $objetPremierGroupe->getListeVerbeConjugue();
var_dump($premierGroupe);


echo "<h2>Deuxi�me groupe : </h2>";
$deuxiemeGroupe = $objetDeuxiemeGroupe->getListeVerbeConjugue();
var_dump($deuxiemeGroupe);


echo "<h2>Troisi�me groupe : </h2>";
$troisiemeGroupe = $objetTroisiemeGroupe->getListeVerbeConjugue();
var_dump($troisiemeGroupe);

?>