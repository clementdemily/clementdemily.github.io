<center><h1>Test du composant Verbe</h1></center>
<div>
	<form action="testComposant.php" method="post" >
		<label>Entrez un verbe conjugu� pour obtenir sa forme infinitif : <br/></label>
			<input type="text" value="" name="verbe" id="id_verbe" class="class_verbe" />
	</form>
</div>


<?php
if((isset($_POST)) AND (!empty($_POST)))
{
	require_once ("Verbe/class.verbe.php");


	$verbe = $_POST['verbe'];

	$objetVerbe = new verbe($listeVerbe);

	$tab = $objetVerbe->getListeVerbeConjugue();
	$verbeRaciniser = $objetVerbe->getInfinitif($verbe);

		if(is_bool($verbeRaciniser))
		{
			if($verbeRaciniser == false )
				echo "Ce mot n'est pas un verbe.";	
		}
		else
			echo "Ce mot est un verbe. <br/>
				  L'infinitif de <em>{$_POST["verbe"]}</em> est <strong>$verbeRaciniser</strong>.";
}
		
?>