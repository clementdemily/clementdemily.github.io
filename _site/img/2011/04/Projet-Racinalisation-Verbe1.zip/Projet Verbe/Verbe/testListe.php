<center><h1>Test de la liste des verbes des trois groupes</h1></center>
<?php

require_once "List/listeVerbe.php";

var_dump($listeVerbe);


?>