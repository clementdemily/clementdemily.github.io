<?php

/*
*	@Auteur : DEMILY Cl�ment, SARCY Romain
*	@Date	: 01/04/11
*/

// $listeVerbeTroisiemeGroupe = array(

									// "accroitre","acqu�rir","aller","battre","boire","bouillir","clore","combattre",
									// "commettre","comprendre","compromettre","concevoir","conclure","concourir","conduire","confondre",
									// "connaitre","construire","contenir","contrefaire","convaincre","convenir","correspondre","courir"
									// ,"couvrir","craindre","croire","cuire","d�battre","d�cevoir","d�coudre","d�couvrir",
									// "d�crire","d�croitre","d�duire","d�faire","d�fendre","d�mentir","d�tendre","d�tenir",
									// "d�rtuire","devenir","devoir","dire","disparaitre","dormir","�crire","�mettre",
									// "endormir","entreprendre","entretenir","entrevoir","�teindre","extraire","�lire","enfuir",
									// "entendre","�mouvoir","�clore","entrouvrir","encourir","faire","falloir","feindre"
									// ,"fendre","fondre","frire","fuir","inclure","induire","inscrire","interdire","interrompre",
									// "intervenir","introduire","lire","maintenir","mettre","readmettre","mentir","rendre",
									// "m�prendre","mordre","mourir","naitre","nuire","venir","obtenir","joindre","ouvrir",
									// "offrir","paraitre","parcourir","r�appara�tre","partir","parvenir","peindre","pendre","recevoir",
									// "perdre","permettre","plaindre","poindre","pondre","pourfendre","parfaire","parfondre","pourvoir",
									// "plaire","predire","pressentir","pretendre","prevaloir","prevenir","prendre","r�apprendre","redescendre",
									// "redevenir","refondre","refendre","rejoindre","remettre","remordre","renaitre","r�pandre","repartir",
									// "repeindre","r�partir","r�pondre","reprendre","ressentir","ressortir","restreindre","retenir",
									// "retordre","tordre","revendre","revenir","rev�tir","vivre","revivre","revoir","revouloir","rire",
									// "rompre","savoir","sentir","servir","sortir","soumettre","sourire","traire","soustraire","soutenir",
									// "souvenir","suivre","subvenir","surprendre","survenir","survivre","susprendre","taire","teindre",
									// "tenir","tendre","tondre","transmettre","transparaitre","vaincre","valoir","vendre","v�tir","voir","vouloir"
// );	

	$listeVerbeTroisiemeGroupe = array(	
								"accroitre"=> array(
													array("accrois","accrois", "accroit", "accroissons","accroissez", "accroissent" ),
													array("accroitrai","accroitras","accroitra","accoitrons", "accroitrez","accroitront"),
													array("acccroissais","acccroissais","acccroissait","acccroissions","acccroissiez","acccroissaient"),
													array("acccru","acccru","acccru","acccru","acccru","acccru"),
													array("accrus","accrus","accru","accrumes","accrutes","accrurent"),
													array("acccroitrais","accroitrais","accroitrait","accroitrions","accroitriez","accroitraient")
													),		
								"acqu�rir"=> array(
													array("acquiers","acquiers","acquiert","acqu�rons","acqu�rez","acqui�rent"),
													array("acquerrai", "acquerras","acquerra","acquerrons","acquerrez", "acquerront"),
													array("acqu�rais", "acqu�rais","acqu�rait", "acqu�rions","acqu�riez","acqu�raient"),
													array("acquis","acquis","acquis","acquis","acquis","acquis"),
													array("acquis","acquis","acquit","acqu�mes","acqu�tes","acquirent"),
													array("acquerrais","acquerrais","acquerrait","acquerrions","acquerriez","acquerraient")
													),
								"aller"=> array(
													array("vais","vas","va","allons","allez","vont"),
													array("irai","iras","ira","irons","irez","iront"),
													array("allais","allais","allait","allions","alliez","allaient"),
													array("all�","all�","all�","all�s","all�s","all�s"),
													array("allai","allas","alla","all�mes","all�tes","all�rent"),
													array("irais","irais","irait","irions","iriez","iraient")
													),
								"battre"=>array(
													array("bats","bats","bat","battons","battez","battent"),
													array("battrai","battras","battra","battrons","battrez","battront"),
													array("battais","battais","battait","battions","battiez","battaient"),
													array("battu","battu","battu","battu","battu","battu"),
													array("battis","battis","battit","batt�mes","batt�tes","battirent"),
													array("battrais","battrais","battrait","battrions","battriez","battraient")
													),		
								 "boire"=> array(
													array("bois","bois","boit","buvons","buvez","boivent"),
													array("boirai","boira","boirons","boirez","boiront"),
													array("buvais","buvais","buvait","buvions","buviez","buvaient"),
													array("bu","bu","bu","bu","bu","bu"),
													array("bus","bus","but","b�mes","b�tes","burent"),
													array("boirais","boirais","boirait","boiriez","boiraient")
													),
								"bouillir"=> array(
													array("bous","bous","butt","boullons","boullez","boullent"),
													array("bouillirai","bouilliras","bouilliera","bouillierons","bouillierez","bouilliront"),
													array("bouillais","bouillais","bouillait","boullions","boulliez","bouillerent"),
													array("bouilli","bouilli","bouilli","bouilli","bouilli","bouilli"),
													array("bouillis","bouillis","bouillit","bouill�mes","bouill�tes","bouillirent"),
													array("bouillirais","bouillirais","bouillirait","bouillirions","bouilliriez","bouilliraient")
													),
							    "clore"=> array(
													array("clos","clos","clot","closent"),
													array("clorai","cloras","clora","clorons","clorez","cloront"),
													array(""),
													array("clos","clos","clos","clos","clos","clos"),
													array(""),
													array("clorais","clorais","clorait","clorions","cloriez","cloraient")
													),
								"combattre"=>array(
													array("combats","combats","combat","combattons","combattez","combattent"),
													array("combattrai","combattras","combattra","combattrons","combattrez","combattront"),
													array("combattais","combattais","combattait","combattions","combattiez","combattaient"),
													array("combattu","combattu","combattu","combattu","combattu","combattu"),
													array("combattis","combattis","combattit","combatt�mes","combatt�tes","combattirent"),
													array("combattrais","combattrais","combattrait","combattrions","combattriez","combattraient")
													),
								"commettre"=>array(
													array("commets","vommets","commet","commettons","commettez","commettent"),
													array("commettrai","commettras","commettra","commettrons","commettrez","commettront"),
													array("commettais","commettais","commettait","commettions","commettiez","commettaient"),
													array("commis","commis","commis","commis","commis","commis"),
													array("commis","commis","commit","comm�mes","comm�tes","commirent"),
													array("commettrais","commettrais","commettrait","commettrions","commettriez","commettraient")
													),
													
								"comprendre"=>array(
													array("comprends","comprends","comprend","comprenons","comprenez","comprennent"),
													array("comprendrai","comprendras","comprendra","comprendrons","comprendrez","comprendront"),
													array("comprenais","comprenais","comprenait","comprenions","compreniez","comprenaient"),
													array("compris","compris","compris","compris","compris","compris"),
													array("compris","compris","comprit","compr�mes","compr�tes","comprirent"),
													array("comprendrais","comprendrais","comprendrait","comprendrions","comprendriez","comprendraient")
													),
								"compromettre"=>array(
													 array("compromets","compromets","compromet","compromettons","compromettez","compromettent"),
													 array("compromettrai","compromettras","compromettra","compromettrons","compromettrez","compromettront"),
													 array("compromettais","compromettais","compromettait","compromettions","compromettiez","compromettaient"),
													 array("compromis","compromis","compromis","compromis","compromis","compromis"),
													 array("compromis","compromis","compromit","comprom�mes","comprom�tes","compromirent"),
													 array("compromettrais","compromettrais","compromettrait","compromettrions","compromettriez","compromettraient")
													 ),	
								"concevoir"=>array(
													 array("con�ois","con�ois","con�oit","concevons","concevez","con�oivent"),
													 array("concevrai","concevras","concevra","concevrons","concevrez","concevront"),
													 array("concevais","concevais","concevait","concevions","conceviez","concevaient"),
													 array("con�u","con�u","con�u","con�u","con�u","con�u",),
													 array("con�us","con�us","con�ut","con��mes","con��tes","con�urent"),
													 array("concevrais","concevrais","concevrait","concevrions","concevriez","concevraient")
													 ),
								"conclure"=>array(
													 array("conclus","conclus","conclut","concluons","concluez","concluent"),
													 array("conclurai","concluras","conclura","conclurons","conclurez","concluront"),
													 array("concluais","concluais","concluait","concluions","concluiez","concluaient"),
													 array("conclu","conclu","conclu","conclu","conclu","conclu"),
													 array("conclus","conclus","conclut","concl�mes","concl�tes","conclurent"),
													 array("conclurais","conclurais","conclurait","conclurions","concluriez","concluraient")
													 ),
								"concourir"=>array(
													 array("concours","concours","concourt","concourons","concourez","concourent"),
													 array("concourrai","concourras","concourra","concourrons","concourrez","concourront"),
													 array("concourais","concourais","concourait","concourions","concouriez","concouraient"),
													 array("concouru","concouru","concouru","concouru","concouru","concouru"),
													 array("concourus","concourus","concourut","concour�mes","concour�tes","concoururent"),
													 array("concourrais","concourrais","concourrait","concourrions","concourriez","ils concourraient")
													 ),
								"conduire"=>array(
													 array("conduis","conduis","conduit","conduisons","conduisez","conduisent"),
													 array("conduirai","conduiras","conduira","conduirons","conduirez","conduiront"),
													 array("conduisais","conduisais","conduisait","conduisions","conduisiez","conduisaient"),
													 array("conduit","conduit","conduit","conduit","conduit","conduit"),
													 array("conduisis","conduisis","conduisit","conduis�mes","conduis�tes","conduisirent"),
													 array("conduirais","conduirais","conduirait","conduirions","conduiriez","conduiraient")
													), 
								"confondre"=>array(
													 array("confonds","confonds","confond","confondons","confondez","confondent"),
													 array("confondrai","confondras","confondra","confondrons","confondrez","confondront"),
													 array("confondais","confondais","confondait","confondions","confondiez","confondaient"),
													 array("confondu","confondu","confondu","confondu","confondu","confondu"),
													 array("confondis","confondis","confondit","confond�mes","confond�tes","confondirent"),
													 array("confondrais","confondrais","confondrait","confondrions","confondriez","confondraient")
													 ),
								"connaitre"=>array(
													 array("connais","connais","conna�t","connaissons","connaissez","connaissent"),
													 array("conna�trai","conna�tras","conna�tra","conna�trons","conna�trez","conna�tront"),
													 array("connaissais","connaissais","connaissait","connaissions","connaissiez","connaissaient"),
													 array("connu","connu","connu","connu","connu","connu"),
													 array("connus","connus","connut","conn�mes","conn�tes","connurent"),
													 array("conna�trais","conna�trais","conna�trait","conna�trions","conna�triez","conna�traient")
													 ),
							   "construire"=>array(
													 array("construis","construis","construit","construisons","construisez","construisent"),
													 array("construirai","construiras","construira","construirons","construirez","construiront"),
													 array("construisais","construisais","construisait","construisions","construisiez","construisaient"),
													 array("construit","construit","construit","construit","construit","construit"),
													 array("construisis","construisis","construisit","construis�mes","construis�tes","construisirent"),
													 array("construirais","construirais","construirait","construirions","construiriez","construiraient")
													 ),
								"contenir"=>array(
													 array("contiens","contiens","contient","contenons","contenez","contiennent"),
													 array("contiendrait","contiendras","contiendra","contiendrons","contiendrez","contiendront"),
													 array("contenais","contenais","contenait","contenions","conteniez","contenaient"),
													 array("contenu","contenu","contenu","contenu","contenu","contenu"),
													 array("contins","contins","contint","cont�nmes","cont�ntes","continrent"),
													 array("contiendrais","contiendrais","contiendrait","contiendrions","contiendriez","contiendraient")
													 ),
								"contrefaire"=>array(
													 array("contrefais","contrefais","contrefait","contrefaisons","contrefaites","contrefont"),
													 array("contreferai","contreferas","contrefera","contreferons","contreferez","contreferont"),
													 array("contrefaisais","contrefaisais","contrefaisait","contrefaisions","contrefaisiez","contrefaisaient"),
													 array("contrefait","contrefait","contrefait","contrefait","contrefait","contrefait"),
													 array("contrefis","contrefis","contrefit","contref�mes","contref�tes","contrefirent"),
													 array("contreferais","contreferais","contreferait","contreferions","contreferiez","contreferaient")
													 ),
								"convaincre"=>array(
													 array("convaincs","convaincs","convainc","convainquons","convainquez","convainquent"),
													 array("convaincrai","convaincras","convaincra","convaincrons","convaincrez","convaincront"),
													 array("convainquais","tu convainquais","convainquait","convainquions","convainquiez","convainquaient"),
													 array("convaincu","convaincu","convaincu","convaincu","convaincu","convaincu"),
													 array("convainquis","convainquis","convainquit","convainqu�mes","convainqu�tes","convainquirent"),
													 array("convaincrais","convaincrais","convaincrait","convaincrions","convaincriez","convaincraient")
													 ),
								"convenir"=>array(
													 array("conviens","conviens","convient","convenons","convenez","conviennent"),
													 array("conviendrai","conviendras","conviendra","conviendrons","conviendrez","conviendront"),
													 array("convenais","convenais","convenait","convenions","conveniez","convenaient"),
													 array("convenu","convenu","convenu","convenu","convenu","convenu"),
													 array("convins","convins","convint","conv�nmes","conv�ntes","convinrent"),	
													 array("conviendrais","conviendrais","conviendrait","conviendrions","conviendriez","conviendraient")
													 ),
								"correspondre"=>array(
													 array("corresponds","corresponds","correspond","correspondons","correspondez","correspondent"),
													 array("correspondrait","correspondras","correspondra","correspondrons","correspondrez","correspondront"),
													 array("correspondais","correspondais","correspondait","correspondions","correspondiez","correspondaient"),
													 array("correspondu","correspondu","correspondu","correspondu","correspondu","correspondu"),
													 array("correspondis","correspondis","correspondit","correspond�mes","correspond�tes","ils correspondirent"),
													 array("correspondrais","correspondrais","correspondrait","correspondrions","correspondriez","correspondraient")
													 ),
								"courir"=>array(
													 array("cours","cours","court","courons","courez","courent"),
													 array("courrai","courras","courra","courrons","courrez","courront"),
													 array("courais","courais","courait","courions","couriez","couraient"),
													 array("couru","couru","couru","couru","couru","couru"),
													 array("courus","courus","courut","cour�mes","cour�tes","coururent"),
													 array("courrais","courrais","courrait","courrions","courriez","courraient")
													 ),
								"couvrir"=>array(
													 array("couvre","couvres","couvren","couvrons","couvrez","couvrent"),
													 array("couvrirai","couvriras","couvrira","couvrirons","couvrirez","couvriront"),
													 array("couvrais","couvrais","couvrait","couvrions","couvriez","couvraient"),
													 array("couvert","couvert","couvert","couvert","couvert","couvert"),
													 array("couvris","couvris","couvrit","couvr�mes","couvr�tes","couvrirent"),
													 array("couvrirais","couvrirais","couvrirait","couvririons","couvririez","couvriraient")
													 ),
								"craindre"=>array(
													 array("crains","crains","craint","craignons","craignez","craignent"),
													 array("craindrai","craindras","craindra","craindrons","craindrez","craindront"),
													 array("craignais","craignais","craignait","craignions","craigniez","craignaient"),
													 array("craint","craint","craint","craint","craint","craint"),
													 array("craignis","craignis","craignit","craign�mes","craign�tes","craignirent"),
													 array("craindrais","craindrais","craindrait","craindrions","craindriez","craindraient")
													 ),
								"croire"=>array(
													 array("crois","crois","croit","croyons","croyez","croient"),
													 array("croirai","croiras","croira","croirons","croirez","croiront"),
													 array("croyais","croyais","croyait","croyions","croyiez","croyaient"),
													 array("cru","cru","cru","cru","cru","cru"),
													 array("crus","crus","crut","cr�mes","cr�tes","crurent"),
													 array("croirais","croirais","croirait","croirions","croiriez","croiraient")
													 ),
								"cuire"=>array(
													 array("cuis","cuis","cuit","cuisons","cuisez","cuisent"),
													 array("cuirai","cuiras","cuira","cuirons","cuirez","cuiront"),
													 array("cuisais","cuisais","cuisait","cuisions","cuisiez","cuisaient"),
													 array("cuit","cuit","cuit","cuit","cuit","cuit"),
													 array("cuisis","cuisis","cuisit","cuis�mes","cuis�tes","cuisirent"),
													 array("cuirais","cuirais","cuirait","cuirions","cuiriez","cuiraient")
													 ),
								"d�battre"=>array(
													 array("d�bats","d�bats","d�bat","d�battons","d�battez","d�battent"),
													 array("je d�battrai","d�battras","d�battra","d�battrons","d�battrez","d�battront"),
													 array("d�battais","d�battais","d�battait","d�battions","d�battiez","d�battaient"),
													 array("d�battu","d�battu","d�battu","d�battu","d�battu","d�battu"),
													 array("d�battis","d�battis","d�battit","d�batt�mes","d�batt�tes","d�battirent"),
													 array("d�battrais","d�battrais","d�battrait","d�battrions","d�battriez","d�battraient")
													 ),
								"d�cevoir"=>array(
													 array("d��ois","d��ois","d��oit","d�cevons","d�cevez","d��oivent"),
													 array("d�cevrai","d�cevras","d�cevra","d�cevrons","d�cevrez","d�cevront"),
													 array("d�cevais","d�cevais","d�cevait","d�cevions","d�ceviez","d�cevaient"),
													 array("d��u","d��u","d��u","d��u","d��u","d��u"),	
													 array("d��us","d��us","d��ut","d���mes","d���tes","d��urent"),
													 array("d�cevrais","d�cevrais","d�cevrait","d�cevrions","d�cevriez","d�cevraient")
													 ),
								"d�coudre"=>array(
													 array("d�couds","d�couds","d�coud","d�cousons","d�cousez","d�cousent"),
													 array("d�coudrai","d�coudras","d�coudra","d�coudrons","d�coudrez","d�coudront"),
													 array("d�cousais","d�cousais","d�cousait","d�cousions","d�cousiez","d�cousaient"),
													 array("d�cousu","d�cousu","d�cousu","d�cousu","d�cousu","d�cousu"),
													 array("d�cousis","d�cousis","d�cousit","d�cous�mes","d�cous�tes","d�cousirent"),
													 array("d�coudrais","d�coudrais","d�coudrait","d�coudrions","d�coudriez","d�coudraient")
													 ),
								"d�couvrir"=>array(
													 array("d�couvre","d�couvres","d�couvre","d�couvrons","d�couvrez","d�couvrent"),
													 array("d�couvrirai","d�couvriras","d�couvrira","d�couvrirons","d�couvrirez","d�couvriront"),
													 array("d�couvrais","d�couvrais","d�couvrait","d�couvrions","d�couvriez","d�couvraient"),
													 array("d�couvert","d�couvert","d�couvert","d�couvert","d�couvert","d�couvert"),
													 array("d�couvris","d�couvris","d�couvrit","d�couvr�mes","d�couvr�tes","d�couvrirent"),	
													 array("d�couvrirais","d�couvrirais","d�couvrirait","d�couvririons","d�couvririez","d�couvriraient")
													 ),
								"d�crire"=>array(
													 array("d�cris","d�cris","d�crit","d�crivons","d�crivez","d�crivent"),
													 array("d�crirai","d�criras","d�crira","d�crirons","d�crirez","d�criront"),
													 array("d�crivais","d�crivais","d�crivait","d�crivions","d�criviez","d�crivaient"),
													 array("d�crit","d�crit","d�crit","d�crit","d�crit","d�crit"),	
													 array("d�crivis","d�crivis","d�crivit","d�criv�mes","d�criv�tes","d�crivirent"),
													 array("d�crirais","d�crirais","d�crirait","d�cririons","d�cririez","d�criraient")
													 ),
								"d�croitre"=>array(
													 array("d�crois","d�crois","d�cro�t","d�croissons","d�croissez","d�croissent"),
													 array("d�cro�trai","d�cro�tras","d�cro�tra","d�cro�trons","d�cro�trez","d�cro�tront"),
													 array("d�croissais","d�croissais","d�croissait","d�croissions","d�croissiez","d�croissaient"),
													 array("d�cru","d�cru","d�cru","d�cru","d�cru","d�cru"),
													 array("d�crus","d�crus","d�cr�t","d�cr�mes","d�cr�tes","d�crurent"),
													 array("d�cro�trais","d�cro�trais","d�cro�trait","d�cro�trions","d�cro�triez","d�cro�traient")
													),
								"d�duire"=>array(
													 array("d�duis","d�duis","d�duit","d�duisons","d�duisez","d�duisent"),
													 array("d�duirai","d�duiras","d�duira","d�duirons","d�duirez","d�duiront"),
													 array("d�duisais","d�duisais","d�duisait","d�duisions","d�duisiez","d�duisaient"),
													 array("d�duit","d�duit","d�duit","d�duit","d�duit","d�duit",),
													 array("d�duisis","d�duisis","d�duisit","d�duis�mes","d�duis�tes","ils d�duisirent"),
													 array("d�duirais","d�duirais","d�duirait","d�duirions","d�duiriez","ils d�duiraient")
													 ),
								"d�faire"=>array(
													 array("d�fais","d�fais","d�fait","d�faisons","d�faites","d�font"),
													 array("d�ferai","d�feras","d�fera","d�ferons","d�ferez","d�feront"),
													 array("d�faisais","d�faisais","d�faisait","d�faisions","d�faisiez","d�faisaient"),
													 array("d�fait","d�fait","d�fait","d�fait","d�fait","d�fait"),
													 array("d�fis","d�fis","d�fit","d�f�mes","d�f�tes","d�firent"),
													 array("d�ferais","d�ferais","d�ferait","d�ferions","d�feriez","d�feraient")					 				 
													 ),
								"d�fendre"=>array(
													 array("d�fais","d�fais","d�fait","d�faisons","d�faites","d�font"),
													 array("d�ferai","d�feras","d�fera","d�ferons","d�ferez","d�feront"),
													 array("d�faisais","d�faisais","d�faisait","d�faisions","d�faisiez","d�faisaient"),
													 array("d�fait","d�fait","d�fait","d�fait","d�fait","d�fait"),
													 array("d�fis","d�fis","d�fit","d�f�mes","d�f�tes","d�firent"),
													 array("d�ferais","d�ferais","d�ferait","d�ferions","d�feriez","d�feraient")
													 ),
								"d�mentir"=>array(
													 array("d�mens","d�mens","d�ment","d�mentons","d�mentez","d�mentent"),
													 array("d�mentirai","d�mentiras","d�mentira","d�mentirons","d�mentirez","d�mentiront"),
													 array("d�mentais","d�mentais","d�mentait","d�mentions","d�mentiez","d�mentaient"),
													 array("d�menti","d�menti","d�menti","d�menti","d�menti","d�menti"),
													 array("d�mentis","d�mentis","d�mentit","d�ment�mes","d�ment�tes","d�mentirent"),
													 array("d�mentirais","d�mentirais","d�mentirait","d�mentirions","d�mentiriez","d�mentiraient")
													 ),
								"d�tendre"=>array(
													 array("d�tends","d�tends","d�tend","d�tendons","d�tendez","ils d�tendent"),
													 array("d�tendrai","d�tendras","d�tendra","d�tendrons","d�tendrez","d�tendront"),
													 array("d�tendais","d�tendais","d�tendait","d�tendions","d�tendiez","d�tendaient"),
													 array("d�tendu","d�tendu","d�tendu","d�tendu","d�tendu","d�tendu"),
													 array("d�tendis","d�tendis","d�tendit","d�tend�mes","d�tend�tes","d�tendirent"),
													 array("d�tendrais","d�tendrais","d�tendrait","d�tendrions","d�tendriez","d�tendraient")
													 ),
								"d�tenir"=>array(
													 array("d�tiens","d�tiens","d�tient","d�tenons","d�tenez","d�tiennent"),
													 array("d�tiendrai","d�tiendras","d�tiendra","d�tiendrons","d�tiendrez","d�tiendront"),
													 array("d�tenais","d�tenais","d�tenait","d�tenions","d�teniez","d�tenaient"),
													 array("d�tenu","d�tenu","d�tenu","d�tenu","d�tenu","d�tenu"),
													 array("d�tins","d�tins","d�tint","d�t�nmes","d�t�ntes","d�tinrent"),
													 array("d�tiendrais","d�tiendrais","d�tiendrait","d�tiendrions","d�tiendriez","d�tiendraient")
													 ),
								"d�rtuire"=>array(
													 array("d�truis","d�truis","d�truit","d�truisons","d�truisez","d�truisent"),
													 array("d�truirai","d�truiras","d�truira","d�truirons","d�truirez","d�truiront"),
													 array("d�truisais","d�truisais","d�truisait","d�truisions","d�truisiez","d�truisaient"),
													 array("d�truit","d�truit","d�truit","d�truit","d�truit","d�truit"),
													 array("d�truisis","d�truisis","d�truisit","d�truis�mes","d�truis�tes","d�truisirent"),
													 array("d�truirais","d�truirais","d�truirait","d�truirions","d�truiriez","d�truiraient"),
													 ),				 
								"devenir"=>array(
													 array("deviens","deviens","devient","devenons","devenez","deviennent"),
													 array("deviendrai","deviendras","deviendra","deviendrons","deviendrez","deviendront"),
													 array("devenais","devenais","devenait","devenions","deveniez","devenaient"),
													 array("devenu","devenu","devenu","devenus","devenus","devenus"),
													 array("devins","devins","devint","dev�nmes","dev�ntes","devinrent"),
													 array("deviendrais","deviendrais","deviendrait","deviendrions","deviendriez","deviendraient")
													 ),
								"devoir"=>array(
													 array("dois","dois","doit","devons","devez","doivent"),
													 array("devrai","devras","devra","devrons","devrez","devront"),
													 array("devais","devais","devait","devions","deviez","ils devaient"),
													 array("du","du","du","du","du","du"),
													 array("dus","dus","dut","d�mes","d�tes","durent"),
													 array("devrais","devrais","devrait","devrions","devriez","devraient"),
													 )	,		 
								"dire"=>array(
													 array("dis","dis","dit","disons","dites","disent"),
													 array("dirai","diras","dira","dirons","direz","diront"),
													 array("disais","disais","disait","disions","disiez","disaient"),
													 array("dit","dit","dit","dit","dit","dit"),
													 array("dis","dis","dit","d�mes","d�tes","dirent"),
													 array("dirais","dirais","dirait","dirions","diriez","diraient")
													 ),
								"disparaitre"=>array(
													 array("disparais","disparais","dispara�t","disparaissons","disparaissez","disparaissent"),
													 array("dispara�trai","dispara�tras","dispara�tra","dispara�trons","dispara�trez","dispara�tront"),
													 array("disparaissais","disparaissais","disparaissait","disparaissions","disparaissiez","disparaissaient"),
													 array("disparu","disparu","disparu","disparu","disparu","disparu"),
													 array("disparus","disparus","disparut","dispar�mes","dispar�tes","disparurent"),
													 array("dispara�trais","dispara�trais","dispara�trait","dispara�trions","dispara�triez","dispara�traient"),
													 ),		
								"dormir"=>array(
													 array("dors","dors","dort","dormons","dormez","dorment"),
													 array("dormirai","dormiras","dormira","dormirons","dormirez","dormiront"),
													 array("dormais","dormais","dormait","dormions","dormiez","dormaient"),
													 array("dormi","dormi","dormi","dormi","dormi","dormi"),
													 array("dormis","dormis","dormit","dorm�mes","dorm�tes","dormirent"),
													 array("dormirais","dormirais","dormirait","dormirions","dormiriez","dormiraient")
													 ),		 
								"�crire"=>array(
													 array("�cris","�cris","�crit","�crivons","�crivez","�crivent"),
													 array("�crirai","�criras","�crira","�crirons","�crirez","�criront"),
													 array("�crivais","�crivais","�crivait","�crivions","�criviez","�crivaient"),
													 array("�crit","�crit","�crit","�crit","�crit","�crit"),
													 array("�crivis","�crivis","�crivit","�criv�mes","�criv�tes","�crivirent"),
													 array("�crirais","�crirais","�crirait","�cririons","�cririez","�criraient")
													 ),
								"�mettre"=>array(
													 array("�mets","�mets","�met","�mettons","�mettez","�mettent"),
													 array("�mettrai","�mettras","�mettra","�mettrons","�mettrez","�mettront"),
													 array("�mettais","�mettais","�mettait","�mettions","�mettiez","�mettaient"),
													 array("�mis","�mis","�mis","�mis","�mis","�mis"),
													 array("�mis","�mis","�mit","�m�mes","�m�tes","�mirent"),
													 array("�mettrais","�mettrais","�mettrait","�mettrions","�mettriez","�mettraient")
													 ),
								"endormir"=>array(
													 array("endors","endors","endort","endormons","endormez","endorment"),
													 array("endormirai","endormiras","endormira","endormirons","endormirez","endormiront"),
													 array("endormais","endormais","endormait","endormions","endormiez","endormaient"),
													 array("endormi","endormi","endormi","endormi","endormi","endormi"),
													 array("endormis","endormis","endormit","endorm�mes","endorm�tes","endormirent"),
													 array("endormirais","endormirais","endormirait","endormirions","endormiriez","endormiraient")
													 ),
								"entreprendre"=>array(
													 array("entreprends","entreprends","entreprend","entreprenons","entreprenez","entreprennent"),
													 array("entreprendrai","entreprendras","entreprendra","entreprendrons","entreprendrez","entreprendront"),
													 array("entreprenais","entreprenais","entreprenait","entreprenions","entrepreniez","entreprenaient"),
													 array("entrepris","entrepris","entrepris","entrepris","entrepris","entrepris"),
													 array("entrepris","entrepris","entreprit","entrepr�mes","entrepr�tes","entreprirent"),
													 array("entreprendrais","entreprendrais","entreprendrait","entreprendrions","entreprendriez","entreprendraient")
													 ),					 
								"entretenir"=>array(
													 array("entretiens","entretiens","entretient","entretenons","entretenez","entretiennent"),
													 array("entretiendrai","entretiendras","entretiendra","entretiendrons","entretiendrez","entretiendront"),
													 array("entretenais","entretenais","entretenait","entretenions","entreteniez","entretenaient"),
													 array("entretenu","entretenu","entretenu","entretenu","entretenu","entretenu"),
													 array("entretins","entretins","entretint","entret�nmes","entret�ntes","entretinrent"),
													 array("entretiendrais","entretiendrais","entretiendrait","entretiendrions","entretiendriez","entretiendraient")
													 ),
	 
								"entrevoir"=>array(
													 array("entrevois","entrevois","entrevoit","entrevoyons","entrevoyez","entrevoient"),
													 array("entreverrai","entreverras","entreverra","entreverrons","entreverrez","entreverront"),
													 array("entrevoyais","entrevoyais","entrevoyait","entrevoyions","entrevoyiez","entrevoyaient"),
													 array("entrevu","entrevu","entrevu","entrevu","entrevu","entrevu"),
													 array("entrevis","entrevis","entrevit","entrev�mes","entrev�tes","entrevirent"),
													 array("entreverrais","entreverrais","entreverrait","entreverrions","entreverriez","entreverraient")
													 ),			 
								"�teindre"=>array(	
													 array("�teins","�teins","�teint","�teignons","�teignez","�teignent"),
													 array("�teindrai","�teindras","�teindra","�teindrons","�teindrez","�teindront"),
													 array("�teignais","�teignais","�teignait","�teignions","�teigniez","�teignaient"),
													 array("�teint","�teint","�teint","�teint","�teint","�teint"),
													 array("�teignis","�teignis","�teignit","�teign�mes","�teign�tes","�teignirent"),
													 array("�teindrais","�teindrais","�teindrait","�teindrions","�teindriez","�teindraient")
													 ),				 	 
								"extraire"=>array(
													 array("extrais","extrais","extrait","extrayons","extrayez","extraient"),
													 array("extrairai","extrairas","extraira","extrairons","extrairez","extrairont"),
													 array("extrayais","extrayais","extrayait","extrayions","extrayiez","extrayaient"),
													 array("extrait","extrait","extrait","extrait","extrait","extrait"),
													 array(""),
													 array("extrairais","extrairais","extrairait","extrairions","extrairiez","extrairaient"),
													 ),	
								"�lire"=>array(
													 array("�lis","�lis","�lit","�lisons","�lisez","�lisent"),
													 array("�lirai","�liras","�lira","�lirons","�lirez","�liront"),
													 array("�lisais","�lisais","�lisait","�lisions","�lisiez","�lisaient"),
													 array("�lu","�lu","�lu","�lu","�lu","�lu"),
													 array("�lus","�lus","�lut","�l�mes","�l�tes","�lurent"),
													 array("�lirais","�lirais","�lirait","�lirions","�liriez","�liraient")
													 ),
								"enfuir"=>array(
													 array("'enfuis","enfuis","enfuit","enfuyons","enfuyez","enfuient"),
													 array("enfuirai","enfuiras","enfuira","enfuirons","enfuirez","enfuiront"),
													 array("enfuyais","enfuyais","enfuyait","enfuyions","enfuyiez","enfuyaient"),
													 array("enfui","enfui","enfui","enfui","enfui","enfui"),
													 array("enfuis","enfuis","enfuit","enfu�mes","enfu�tes","enfuirent"),
													 array("enfuirais","enfuirais","enfuirait","enfuirions","enfuiriez","enfuiraient")	
													 ),
								"entendre"=>array(
													 array("entends","entends","entend","entendons","entendez","entendent"),
													 array("entendrai","entendras","entendra","entendrons","entendrez","entendront"),
													 array("entendais","entendais","entendait","entendions","entendiez","entendaient"),
													 array("entendu","entendu","entendu","entendu","entendu","entendu"),
													 array("entendis","entendis","entendit","entend�mes","entend�tes","entendirent"),
													 array("entendrais","entendrais","entendrait","entendrions","entendriez","entendraient")
													 ),
								"�mouvoir"=>array(
													 array("�meus","�meus","�meut","�mouvons","�mouvez","�meuvent"),
													 array("�mouvrai","�mouvras","�mouvra","�mouvrons","�mouvrez","�mouvront"),
													 array("�mouvais","�mouvais","�mouvait","�mouvions","�mouviez","�mouvaient"),
													 array("�mu","�mu","�mu","�mu","�mu","�mu"),
													 array("�mus","�mus","�mut","�m�mes","�m�tes","�murent"),
													 array("�mouvrais","�mouvrais","�mouvrait","�mouvrions","�mouvriez","�mouvraient"),
													 ),			 
								"�clore"=>array(
													 array("�clos","�clos","�clot","�closons","�closez","�closent"),
													 array("�clorai","�cloras","�clora","�clorons","�clorez","�cloront"),
													 array(""),
													 array("�clos","�clos","�clos","�clos","�clos","�clos"),
													 array(""),
													 array("�clorais","�clorais","�clorait","�clorions","�cloriez","�cloraient")
													 ),
								"entrouvrir"=>array(
													 array("entrouvre","entrouvres","entrouvre","entrouvrons","entrouvrez","entrouvrent"),
													 array("entrouvrirai","entrouvriras","entrouvrira","entrouvrirons","entrouvrirez","entrouvriront"),
													 array("entrouvrais","entrouvrais","entrouvrait","entrouvrions","entrouvriez","entrouvraient"),
													 array("entrouvert","entrouvert","entrouvert","entrouvert","entrouvert","entrouvert"),
													 array("entrouvris","entrouvris","entrouvrit","entrouvr�mes","entrouvr�tes","entrouvrirent"),
													 array("entrouvrirais","entrouvrirais","entrouvrirait","entrouvririons","entrouvririez","entrouvriraient"),
													 ),						 
								"encourir"=>array(
													 array("encours","encours","encourt","encourons","encourez","encourent"),
													 array("encourrai","encourras","encourra","encourrons","encourrez","encourront"),
													 array("encourais","encourais","encourait","encourions","encouriez","encouraient"),
													 array("encouru","encouru","encouru","encouru","encouru","encouru"),
													 array("encourus","encourus","encourut","encour�mes","encour�te","encoururent"),
													 array("encourrais","encourrais","encourrait","encourrions","encourriez","encourraient")
													 ),	
								"dire"=>array(
													 array("dis","dis","dit","disons","dites","disent"),
													 array("dirai","diras","dira","dirons","direz","diront"),
													 array("disais","disais","disait","disions","disiez","disaient"),
													 array("dis","dis","dit","d�mes","d�tes","dirent"),	
													 array("dit","dit","dit","dit","dit","dit"),
													 array("dirais","dirais","dirait","dirions","diriez","diraient")
												),													
								"faire"=>array(
													 array("fais","fais","fait","faisons","faites","font"),
													 array("ferai","feras","fera","ferons","ferez","feront"),
													 array("faisais","faisais","faisait","faisions","faisiez","faisaient"),
													 array("fait","fait","fait","fait","fait","fait",),
													 array("fis","fis","fit","f�mes","f�tes","firent"),
													 array("ferais","ferais","ferait","ferions","feriez","feraient")
												),
								"falloir"=>array(
													 array("faut"),
													 array("faudra"),
													 array("fallait"),
													 array("fallu"),
													 array("fallut"),
												),				
								"feindre"=> array(
													array("feins","feins","feint","feignons","feignez","feignent"),
													array("feint","feint","feint","feint","feint","feint"),
													array("feignais","feignais","feignait","feignions","feigniez","feignaient"),
													array("feignis","feignis","feignit","feign�mes","feign�tes","feignirent"),
													array("feindrai","feindras","feindra","feindrons","feindrez","feindront"),
													array("feindrais","feindrais","feindrait","feindrions","feindriez","feindraient")
												),	
								"fendre"=> array(
													array("fends","fends","fend","fendons","fendez","fendent"),
													array("fendu","fendu","fendu","fendu","fendu","fendu"),
													array("fendais","fendais","fendait","fendions","fendiez","fendaient"),
													array("fendis","fendis","fendit","fend�mes","fend�tes","fendirent"),
													array("fendra","fendras","fendra","fendrons","fendrez","fendraient"),
													array("fendrais","fendrais","fendrait","fendrions","fendriez","fendraient")
												),	
								"fondre"=> array(
													array("fonds","fonds","fond","fondons","fondez","fondent"),
													array("fondu","fondu","fondu","fondu","fondu","fondu"),
													array("fondais","fondais","fondait","fondions","fondiez","fondaient"),
													array("fondis","fondis","fondit","fond�mes","fond�tes","fondirent"),
													array("fondra","fondras","fondra","fondrons","fondrez","fondraient"),
													array("fondrais","fondrais","fondrait","fondrions","fondriez","fondraient")
												),								
								"frire"=> array(
													array("fris","fris","frit","frisons","frisez","frisent"),
													array("frirai","friras","frira","frirons","frirez","friront"),
													array("frisais","frisais","frisait","frisions","frisiez","frisaient"),
													array("frit","frit","frit","frit","frit","frit"),
													array("fris","fris","frit","fr�mes","fr�tes","frirent"),
													array("frirais","frirais","frirait","fririons","fririez","friraient")
												),		
								"fuir"=> array(
													array("fuis","fuis","fuit","fuyons","fuyez","fuient"),
													array("fuirai","fuiras","fuira","fuirons","fuirez","fuiront"),
													array("fuyais","fuyais","fuyait","fuyions","fuyiez","fuyaient"),
													array("fui","fui","fui","fui","fui","fui"),
													array("fuis","fuis","fuit","fu�mes","fu�tes","fuirent"),
													array("fuirais","fuirais","fuirait","fuirions","fuiriez","fuiraient")
												),									
								"inclure"=>array(
													 array("inclus","inclus","inclut","incluons","incluez","incluent"),
													 array("inclurai","incluras","inclura","inclurons","inclurez","incluront"),
													 array("incluais","incluais","incluait","incluions","incluiez","incluaient"),
													 array("inclu","inclu","inclu","inclu","inclu","inclu"),
													 array("inclus","inclus","inclut","incl�mes","incl�tes","inclurent"),
													 array("inclurais","inclurais","inclurait","inclurions","incluriez","incluraient")
													),	
								"induire"=>array(
													 array("induis","induis","induit","induisons","induisez","induisent"),
													 array("induirai","induiras","induira","induirons","induirez","induiront"),
													 array("induisais","induisais","induisait","induisions","induisiez","induisaient"),
													 array("induit","induit","induit","induit","induit","induit"),
													 array("induisis","induisis","induisit","induis�mes","induis�tes","induisirent"),
													 array("induirais","induirais","induirait","induirions","induiriez","induiraient")
													),	
								"inscrire"=>array(
													 array("inscris","inscris","inscrit","inscrivons","inscrivez","inscrivent"),
													 array("inscrirai","inscriras","inscrira","inscrirons","inscrirez","inscriront"),
													 array("inscrivais","inscrivais","inscrivait","inscrivions","inscriviez","inscrivaient"),
													 array("inscrit","inscrit","inscrit","inscrit","inscrit","inscrit"),	
													 array("inscrivis","inscrivis","inscrivit","inscriv�mes","inscriv�tes","inscrivirent"),
													 array("inscrirais","inscrirais","inscrirait","inscririons","inscririez","inscriraient")
												),	
								"interdire"=>array(
													 array("interdis","interdis","interdit","interdisons","interdites","interdisent"),
													 array("interdirai","interdiras","interdira","interdirons","interdirez","interdiront"),
													 array("interdisais","interdisais","interdisait","interdisions","interdisiez","interdisaient"),
													 array("interdis","interdis","interdit","d�mes","d�tes","interdirent"),	
													 array("interdit","interdit","interdit","interdit","interdit","interdit"),
													 array("interdirais","interdirais","interdirait","interdirions","interdiriez","interdiraient")
												),			
								"interrompre"=> array(
													array("interromps","interromps","interromp","interrompons","interrompez","interrompent"),
													array("interrompu","interrompu","interrompu","interrompu","interrompu","interrompu"),
													array("interrompais","interrompais","interrompait","interrompions","interrompiez","interrompaient"),
													array("interrompis","interrompis","interrompit","interromp�mes","interromp�tes","interrompirent"),
													array("interrompis","interrompis","interrompit","interromp�mes","interromp�tes","interrompirent"),
													array("interromprais","interromprais","interromprait","interromprions","interrompriez","interrompraient")
												),		
								"intervenir"=> array(
													array("interviens","interviens","intervient","intervenons","intervenez","interviennent"),
													array("intervenu","intervenu","intervenu","intervenus","intervenus","intervenus"),
													array("intervenais","intervenais","intervenait","intervenions","interveniez","intervenaient"),
													array("intervins","intervins","intervint","interv�nmes","interv�ntes","intervinrent"),
													array("interviendrai","interviendras","interviendra","interviendrons","interviendrez","interviendront"),
													array("interviendrais","interviendrais","interviendrait","interviendrions","interviendriez","interviendraient")
												),		
								"introduire"=>array(
													 array("introduis","introduis","introduit","introduisons","introduisez","introduisent"),
													 array("introduirai","introduiras","introduira","introduirons","introduirez","introduiront"),
													 array("introduisais","introduisais","introduisait","introduisions","introduisiez","introduisaient"),
													 array("introduit","introduit","introduit","introduit","introduit","introduit"),
													 array("introduisis","introduisis","introduisit","introduis�mes","introduis�tes","introduisirent"),
													 array("introduirais","introduirais","introduirait","introduirions","introduiriez","introduiraient")
													),												
								"lire"=> array(
													array("lis","lis","lit","lisons","lisez","lisent"),
													array("lu","lu","lu","lu","lu","lu"),
													array("lisais","lisais","lisait","lisions","lisiez","lisaient"),
													array("lus","lus","lut","l�mes","l�tes","lurent"),
													array("lirai","liras","lira","lirons","lirez","liront"),
													array("lirais","lirais","lirait","lirions","liriez","liraient")
												),							
								"maintenir"=> array(
													array("maintiens","maintiens","maintient","maintenons","maintenez","maintiennent"),
													array("maintenu","maintenu","maintenu","maintenu","maintenu","maintenu"),
													array("maintenais","maintenais","maintenait","maintenions","mainteniez","maintenaient"),
													array("maintins","maintins","maintint","maint�nmes","maint�ntes","maintinrent"),
													array("maintiendrai","maintiendras","maintiendra","maintiendrons","maintiendrez","maintiendront"),
													array("maintiendrais","maintiendrais","maintiendrait","maintiendrions","maintiendriez","maintiendraient")
												),			
								"mettre"=> array(
													array("mets","mets","met","mettons","mettez","mettent"),
													array("mis","mis","mis","mis","mis","mis"),
													array("mettais","mettais","mettait","mettions","mettiez","mettaient"),
													array("mis","mis","mit","m�mes","m�tes","mirent"),
													array("mettrai","mettras","mettra","mettrons","mettrez","mettront"),
													array("mettrais","mettrais","mettrait","mettrions","mettriez","mettraient")
												),		
								"readmettre"=> array(
													array("readmets","readmets","readmet","readmettons","readmettez","readmettent"),
													array("readmis","readmis","readmis","readmis","readmis","readmis"),
													array("readmettais","readmettais","readmettait","readmettions","readmettiez","readmettaient"),
													array("readmis","readmis","readmit","readm�mes","readm�tes","readmirent"),
													array("readmettrai","readmettras","readmettra","readmettrons","readmettrez","readmettront"),
													array("readmettrais","readmettrais","readmettrait","readmettrions","readmettriez","readmettraient")
												),
								"mentir"=> array(
													array("mens","mens","ment","mentons","mentez","mentent"),
													array("menti","menti","menti","menti","menti","menti"),
													array("mentais","mentais","mentait","mentions","mentiez","mentaient"),
													array("mentis","mentis","mentit","ment�mes","ment�tes","mentirent"),
													array("mentirai","mentiras","mentira","mentirons","mentirez","mentiront"),
													array("mentirais","mentirais","mentirait","mentirions","mentiriez","mentiraient")
												),
								"rendre"=> array(
													array("rends","rends","rend","rendons","rendez","rendent"),
													array("rendu","rendu","rendu","rendu","rendu","rendu"),
													array("rendais","rendais","rendait","rendions","rendiez","rendaient"),
													array("rendis","rendis","rendit","rend�mes","rend�tes","rendirent"),
													array("rendis","rendis","rendit","rend�mes","rend�tes","rendirent"),
													array("rendrais","rendrais","rendrait","rendrions","rendriez","rendraient")
												),
								"m�prendre"=> array(
													array("m�prends","m�prends","m�prend","m�prenons","m�prenez","m�prennent"),
													array("m�pris","m�pris","m�pris","m�pris","m�pris","m�pris"),
													array("m�prenais","m�prenais","m�prenait","m�prenions","m�preniez","m�prenaient"),
													array("m�pris","m�pris","m�prit","m�pr�mes","m�pr�tes","m�prirent"),
													array("m�prendrai","m�prendras","m�prendra","m�prendrons","m�prendrez","m�prendront"),
													array("m�prendrais","m�prendrais","m�prendrait","m�prendrions","m�prendriez","m�prendraient")
												),													
								"mordre"=> array(
													array("mords","mords","mord","mordons","mordez","mordent"),
													array("mordu","mordu","mordu","mordu","mordu","mordu"),
													array("mordais","mordais","mordait","mordions","mordiez","mordaient"),
													array("mordis","mordis","mordit","mord�mes","mord�tes","mordimort"),
													array("mordis","mordis","mordit","mord�mes","mord�tes","mordimort"),
													array("mordrais","mordrais","mordrait","mordrions","mordriez","mordraient")
												),	
								"mourir"=> array(
													array("meurs","meurs","meurt","mourons","mourez","meurent"),
													array("mort","mort","mort","morts","morts"),
													array("mourais","mourais","mourait","mourions","mouriez","mouraient"),
													array("mourus","mourus","mourut","mour�mes","mour�tes","moururent"),
													array("mourrai","mourras","mourra","mourrons","mourrez","mourront"),
													array("mourrais","mourrais","mourrait","mourrions","mourriez","mourraient")
												),
								"naitre"=> array(
													array("nais","nais","na�t","naissons","naissez","naissent"),
													array("n�","n�","n�","n�","n�","n�"),
													array("naissais","naissais","naissait","naissions","naissiez","naissaient"),
													array("naquis","naquis","naquit","naqu�mes","naqu�tes","naquirent"),
													array("na�trai","na�tras","na�tra","na�trons","na�trez","na�tront"),
													array("na�trais","na�trais","na�trait","na�trions","na�triez","na�traient")
												),
								"nuire"=> array(
													array("nuis","nuis","nuit","nuisons","nuisez","nuisent"),
													array("nui","nui","nui","nui","nui","nui"),
													array("nuisais","nuisais","nuisait","nuisions","nuisiez","nuisaient"),
													array("nuisis","nuisis","nuisit","nuis�mes","nuis�tes","nuisirent"),
													array("nuirai","nuiras","nuira","nuirons","nuirez","nuiront"),
													array("nuirais","nuirais","nuirait","nuirions","nuiriez","nuiraient")
												),			
								"venir"=> array(
													array("viens","viens","vient","venons","venez","viennent"),
													array("venu","venu","venu","venus","venus","venus"),
													array("venais","venais","venait","venions","veniez","venaient"),
													array("vins","vins","vint","v�nmes","v�ntes","vinrent"),
													array("viendrai","viendras","viendra","viendrons","viendrez","viendront"),
													array("viendrais","viendrais","viendrait","viendrions","viendriez","viendraient")
												),
								"obtenir"=> array(
													array("obtiens","obtiens","obtient","obtenons","obtenez","obtiennent"),
													array("obtenu","obtenu","obtenu","obtenus","obtenus","obtenus"),
													array("obtenais","obtenais","obtenait","obtenions","obteniez","obtenaient"),
													array("obtins","obtins","obtint","obt�nmes","obt�ntes","obtinrent"),
													array("obtiendrai","obtiendras","obtiendra","obtiendrons","obtiendrez","obtiendront"),
													array("obtiendrais","obtiendrais","obtiendrait","obtiendrions","obtiendriez","obtiendraient")
												),		
								"joindre"=> array(
													array("joins","joins","joint","joignons","joignez","joignent"),
													array("joint","joint","joint","joint","joint","joint"),
													array("joignais","joignais","joignait","joignions","joigniez","joignaient"),
													array("joignis","joignis","joignit","joign�mes","joign�tes","joignirent"),
													array("joindrai","joindras","joindra","joindrons","joindrez","joindront"),
													array("joindrais","joindrais","joindrait","joindrions","joindriez","joindraient")
												),
								"ouvrir"=> array(
													array("ouvre","ouvres","ouvre","ouvrons","ouvrez","ouvrent"),
													array("ouvert","ouvert","ouvert","ouvert","ouvert","ouvert"),
													array("ouvrais","ouvrais","ouvrait","ouvrions","ouvriez","ouvraient"),
													array("ouvris","ouvris","ouvrit","ouvr�mes","ouvr�tes","ouvrirent"),
													array("ouvrirai","ouvriras","ouvrira","ouvrirons","ouvrirez","ouvriront"),
													array("ouvrirais","ouvrirais","ouvrirait","ouvririons","ouvririez","ouvriraientnt")
												),		
								"offrir"=>array(
													 array("offre","offres","offre","offrons","offrez","offrent"),
													 array("offrirai","offriras","offrira","offrirons","offrirez","offriront"),
													 array("offrais","offrais","offrait","offrions","offriez","offraient"),
													 array("offert","offert","offert","offert","offert","offert"),
													 array("offris","offris","offrit","offr�mes","offr�tes","offrirent"),
													 array("offrirais","offrirais","offrirait","offririons","offririez","offriraient")
													 ),
								"paraitre"=> array(
													array("parais","parais","para�t","paraissons","paraissez","paraissent"),
													array("paru","paru","paru","paru","paru","paru"),
													array("paraissais","paraissais","paraissait","paraissions","paraissiez","paraissaient"),
													array("parus","parus","parut","par�mes","par�tes","parurent"),
													array("para�trai","para�tras","para�tra","para�trons","para�trez","para�tront"),
													array("para�trais","para�trais","para�trait","para�trions","para�triez","para�traient")
												),		
								"parcourir"=>array(
													 array("parcours","parcours","parcourt","parcourons","parcourez","parcourent"),
													 array("parcourrai","parcourras","parcourra","parcourrons","parcourrez","parcourront"),
													 array("parcourais","parcourais","parcourait","parcourions","parcouriez","parcouraient"),
													 array("parcouru","parcouru","parcouru","parcouru","parcouru","parcouru"),
													 array("parcourus","parcourus","parcourut","parcour�mes","parcour�tes","parcoururent"),
													 array("parcourrais","parcourrais","parcourrait","parcourrions","parcourriez","parcourraient")
													 ),												
								"r�appara�tre"=> array(
													array("r�apparais","r�apparais","r�appara�t","r�apparaissons","r�apparaissez","r�apparaissent"),
													array("r�apparu","r�apparu","r�apparu","r�apparu","r�apparu","r�apparu"),
													array("r�apparaissais","r�apparaissais","r�apparaissait","r�apparaissions","r�apparaissiez","r�apparaissaient"),
													array("r�apparus","r�apparus","r�apparut","r�appar�mes","r�appar�tes","r�apparurent"),
													array("r�appara�trai","r�appara�tras","r�appara�tra","r�appara�trons","r�appara�trez","r�appara�tront"),
													array("r�appara�trais","r�appara�trais","r�appara�trait","r�appara�trions","r�appara�triez","r�appara�traient")
												),						
								"partir"=> array(
													array("pars","pars","part","partons","partez","partent"),
													array("parti","parti","parti","parti","parti","parti"),
													array("partais","partais","partait","partions","partiez","partaient"),
													array("partis","partis","partit","part�mes","part�tes","partirent"),
													array("partirai","partiras","partira","partirons","partirez","partiront"),
													array("partirais","partirais","partirait","partirions","partiriez","partiraient")
												),							
								"venir"=> array(
													array("viens","viens","vient","venons","venez","viennent"),
													array("venu","venu","venu","venus","venus","venus"),
													array("venais","venais","venait","venions","veniez","venaient"),
													array("vins","vins","vint","v�nmes","v�ntes","vinrent"),
													array("viendrai","viendras","viendra","viendrons","viendrez","viendront"),
													array("viendrais","viendrais","viendrait","viendrions","viendriez","viendraient")
												),			
								"parvenir"=> array(
													array("parviens","parviens","parvient","parvenons","parvenez","parviennent"),
													array("parvenu","parvenu","parvenu","parvenus","parvenus","parvenus"),
													array("parvenais","parvenais","parvenait","parvenions","parveniez","parvenaient"),
													array("parvins","parvins","parvint","parv�nmes","parv�ntes","parvinrent"),
													array("parviendrai","parviendras","parviendra","parviendrons","parviendrez","parviendront"),
													array("parviendrais","parviendrais","parviendrait","parviendrions","parviendriez","parviendraient")
												),			
								"peindre"=> array(
													array("peins","peins","peint","peignons","peignez","peignent"),
													array("peint","peint","peint","peint","peint","peint"),
													array("peignais","peignais","peignait","peignions","peigniez","peignaient"),
													array("peignis","peignis","peignit","peign�mes","peign�tes","peignirent"),
													array("peindrai","peindras","peindra","peindrons","peindrez","peindront"),
													array("peindrais","peindrais","peindrait","peindrions","peindriez","peindraient")
												),		
								"pendre"=> array(
													array("pends","pends","pend","pendons","pendez","pendent"),
													array("pendu","pendu","pendu","pendu","pendu","pendu"),
													array("pendais","pendais","pendait","pendions","pendiez","pendaient"),
													array("pendis","pendis","pendit","pend�mes","pend�tes","pendipent"),
													array("pendra","pendras","pendra","pendrons","pendrez","pendraient"),
													array("pendrais","pendrais","pendrait","pendrions","pendriez","pendraient")
												),		
								"recevoir"=> array(
													array("re�ois","re�ois","re�oit","recevons","recevez","re�oivent"),
													array("re�u","re�u","re�u","re�u","re�u","re�u"),
													array("recevais","recevais","recevait","recevions","receviez","recevaient"),
													array("re�us","re�us","re�ut","re��mes","re��tes","re�urent"),
													array("recevrai","recevras","recevra","recevrons","recevrez","recevront"),
													array("recevrais","recevrais","recevrait","recevrions","recevriez","recevraient")
												),
								"perdre"=> array(
													array("perds","perds","perd","perdons","perdez","perdent"),
													array("perdu","perdu","perdu","perdu","perdu","perdu"),
													array("perdais","perdais","perdait","perdions","perdiez","perdaient"),
													array("perdis","perdis","perdit","perd�mes","perd�tes","perdipert"),
													array("perdis","perdis","perdit","perd�mes","perd�tes","perdipert"),
													array("perdrais","perdrais","perdrait","perdrions","perdriez","perdraient")
												),	
								"permettre"=> array(
													array("permets","permets","permet","permettons","permettez","permettent"),
													array("permis","permis","permis","permis","permis","permis"),
													array("permettais","permettais","permettait","permettions","permettiez","permettaient"),
													array("permis","permis","permit","perm�permes","perm�tes","permirent"),
													array("permettrai","permettras","permettra","permettrons","permettrez","permettront"),
													array("permettrais","permettrais","permettrait","permettrions","permettriez","permettraient")
												),	
								"plaindre"=>array(
													 array("plains","plains","plaint","plaignons","plaignez","plaignent"),
													 array("plaindrai","plaindras","plaindra","plaindrons","plaindrez","plaindront"),
													 array("plaignais","plaignais","plaignait","plaignions","plaigniez","plaignaient"),
													 array("plaint","plaint","plaint","plaint","plaint","plaint"),
													 array("plaignis","plaignis","plaignit","plaign�mes","plaign�tes","plaignirent"),
													 array("plaindrais","plaindrais","plaindrait","plaindrions","plaindriez","plaindraient")
													 ),												
								"poindre"=> array(
													array("poins","poins","point","poignons","poignez","poignent"),
													array("point","point","point","point","point","point"),
													array("poignais","poignais","poignait","poignions","poigniez","poignaient"),
													array("poignis","poignis","poignit","poign�mes","poign�tes","poignirent"),
													array("poindrai","poindras","poindra","poindrons","poindrez","poindront"),
													array("poindrais","poindrais","poindrait","poindrions","poindriez","poindraient")
												),						
								"pondre"=> array(
													array("ponds","ponds","pond","pondons","pondez","pondent"),
													array("pondu","pondu","pondu","pondu","pondu","pondu"),
													array("pondais","pondais","pondait","pondions","pondiez","pondaient"),
													array("pondis","pondis","pondit","pond�mes","pond�tes","pondipont"),
													array("pondis","pondis","pondit","pond�mes","pond�tes","pondipont"),
													array("pondrais","pondrais","pondrait","pondrions","pondriez","pondraient")
												),
								"pourfendre"=> array(
													array("pourfends","pourfends","pourfend","pourfendons","pourfendez","pourfendent"),
													array("pourfendu","pourfendu","pourfendu","pourfendu","pourfendu","pourfendu"),
													array("pourfendais","pourfendais","pourfendait","pourfendions","pourfendiez","pourfendaient"),
													array("pourfendis","pourfendis","pourfendit","pourfend�mes","pourfend�tes","pourfendirent"),
													array("pourfendis","pourfendis","pourfendit","pourfend�mes","pourfend�tes","pourfendirent"),
													array("pourfendrais","pourfendrais","pourfendrait","pourfendrions","pourfendriez","pourfendraient")
												),
								"parfaire"=>array(
													 array("parfais","parfais","parfait","parfaisons","parfaites","parfont"),
													 array("parferai","parferas","parfera","parferons","parferez","parferont"),
													 array("parfaisais","parfaisais","parfaisait","parfaisions","parfaisiez","parfaisaient"),
													 array("parfait","parfait","parfait","parfait","parfait","parfait",),
													 array("parfis","parfis","parfit","parf�mes","parf�tes","parfirent"),
													 array("parferais","parferais","parferait","parferions","parferiez","parferaient")
												),
								"parfondre"=> array(
													array("parfonds","parfonds","parfond","parfondons","parfondez","parfondent"),
													array("parfondu","parfondu","parfondu","parfondu","parfondu","parfondu"),
													array("parfondais","parfondais","parfondait","parfondions","parfondiez","parfondaient"),
													array("parfondis","parfondis","parfondit","parfond�mes","parfond�tes","parfondirent"),
													array("parfondis","parfondis","parfondit","parfond�mes","parfond�tes","parfondirent"),
													array("parfondrais","parfondrais","parfondrait","parfondrions","parfondriez","parfondraient")
												),		
								"pourvoir"=> array(
													array("pourvois","pourvois","pourvoit","pourvoyons","pourvoyez","pourvoient"),
													array("pourvu","pourvu","pourvu","pourvu","pourvu","pourvu"),
													array("pourvoyais","pourvoyais","pourvoyait","pourvoyions","pourvoyiez","pourvoyaient"),
													array("pourvus","pourvus","pourvut","pourv�mes","pourv�tes","pourvurent"),
													array("pourvoirai","pourvoiras","pourvoira","pourvoirons","pourvoirez","pourvoiront"),
													array("pourvoirais","pourvoirais","pourvoirait","pourvoirions","pourvoiriez","pourvoiraient")
												),
								"plaire"=> array(
													array("plais","plais","pla�t","plaisons","plaisez","plaisent"),
													array("plu","plu","plu","plu","plu","plu"),
													array("plaisais","plaisais","plaisait","plaisions","plaisiez","plaisaient"),
													array("plus","plus","plut","pl�mes","pl�tes","plurent"),
													array("plairai","plairas","plaira","plairons","plairez","plairont"),
													array("plairais","plairais","plairait","plairions","plairiez","plairaient")
												),
								"predire"=>array(
													 array("predis","predis","predit","predisons","predites","predisent"),
													 array("predirai","prediras","predira","predirons","predirez","prediront"),
													 array("predisais","predisais","predisait","predisions","predisiez","predisaient"),
													 array("predis","predis","predit","d�mes","d�tes","predirent"),	
													 array("predit","predit","predit","predit","predit","predit"),
													 array("predirais","predirais","predirait","predirions","prediriez","prediraient")
												),	
								"pressentir"=> array(
													array("pressens","pressens","pressent","pressentons","pressentez","pressentent"),
													array("pressenti","pressenti","pressenti","pressenti","pressenti","pressenti"),
													array("pressentais","pressentais","pressentait","pressentions","pressentiez","pressentaient"),
													array("pressentis","pressentis","pressentit","pressent�mes","pressent�tes","pressentirent"),
													array("pressentirai","pressentiras","pressentira","pressentirons","pressentirez","pressentiront"),
													array("pressentirais","pressentirais","pressentirait","pressentirions","pressentiriez","pressentiraient")
												),	
								"pretendre"=> array(
													array("pretends","pretends","pretend","pretendons","pretendez","pretendent"),
													array("pretendu","pretendu","pretendu","pretendu","pretendu","pretendu"),
													array("pretendais","pretendais","pretendait","pretendions","pretendiez","pretendaient"),
													array("pretendis","pretendis","pretendit","pretend�mes","pretend�tes","pretendirent"),
													array("pretendrai","pretendras","pretendra","pretendrons","pretendrez","pretendront"),
													array("pretendrais","pretendrais","pretendrait","pretendrions","pretendriez","pretendraient")
												),					
								"prevaloir"=> array(
													array("prevaux","prevaux","prevaut","prevalons","prevalez","prevalent"),
													array("prevalu","prevalu","prevalu","prevalu","prevalu","prevalu"),
													array("prevalais","prevalais","prevalait","prevalions","prevaliez","prevalaient"),
													array("prevalus","prevalus","prevalut","preval�mes","preval�tes","prevalurent"),
													array("prevaudrai","prevaudras","prevaudra","prevaudrons","prevaudrez","prevaudront"),
													array("prevaudrais","prevaudrais","prevaudrait","prevaudrions","prevaudriez","prevaudraient")
												),					
								"prevenir"=> array(
													array("previens","previens","previent","prevenons","prevenez","previennent"),
													array("prevenu","prevenu","prevenu","prevenus","prevenus","prevenus"),
													array("prevenais","prevenais","prevenait","prevenions","preveniez","prevenaient"),
													array("previns","previns","prevint","prev�nmes","prev�ntes","previnrent"),
													array("previendrai","previendras","previendra","previendrons","previendrez","previendront"),
													array("previendrais","previendrais","previendrait","previendrions","previendriez","previendraient")
												),					
								"prendre"=> array(
													array("prends","prends","prend","prenons","prenez","prennent"),
													array("pris","pris","pris","pris","pris","pris"),
													array("prenais","prenais","prenait","prenions","preniez","prenaient"),
													array("pris","pris","prit","pr�mes","pr�tes","prirent"),
													array("prendrai","prendras","prendra","prendrons","prendrez","prendront"),
													array("prendrais","prendrais","prendrait","prendrions","prendriez","prendraient")
												),	
								"r�apprendre"=> array(
													array("r�apprends","r�apprends","r�apprend","prenons","prenez","prennent"),
													array("r�appris","r�appris","r�appris","r�appris","r�appris","r�appris"),
													array("r�apprenais","r�apprenais","r�apprenait","r�apprenions","r�appreniez","r�apprenaient"),
													array("r�appris","r�appris","r�apprit","r�appr�mes","r�appr�tes","r�apprirent"),
													array("r�apprendrai","r�apprendras","r�apprendra","r�apprendrons","r�apprendrez","r�apprendront"),
													array("r�apprendrais","r�apprendrais","r�apprendrait","r�apprendrions","r�apprendriez","r�apprendraient")
												),
								"redescendre"=> array(
													array("redescends","redescends","redescend","redescendons","redescendez","redescendent"),
													array("redescendu","redescendu","redescendu","redescendu","redescendu","redescendu"),
													array("redescendais","redescendais","redescendait","redescendions","redescendiez","redescendaient"),
													array("redescendis","redescendis","redescendit","redescend�mes","redescend�tes","redescendirent"),
													array("redescendra","redescendras","redescendra","redescendrons","redescendrez","redescendraient"),
													array("redescendrais","redescendrais","redescendrait","redescendrions","redescendriez","redescendraient")
												),				
								"redevenir"=> array(
													array("redeviens","redeviens","redevient","redevenons","redevenez","redeviennent"),
													array("redevenu","redevenu","redevenu","redevenus","redevenus","redevenus"),
													array("redevenais","redevenais","redevenait","redevenions","redeveniez","redevenaient"),
													array("redevins","redevins","redevint","redev�nmes","redev�ntes","redevinrent"),
													array("redeviendrai","redeviendras","redeviendra","redeviendrons","redeviendrez","redeviendront"),
													array("redeviendrais","redeviendrais","redeviendrait","redeviendrions","redeviendriez","redeviendraient")
												),		
								"refondre"=> array(
													array("refonds","refonds","refond","refondons","refondez","refondent"),
													array("refondu","refondu","refondu","refondu","refondu","refondu"),
													array("refondais","refondais","refondait","refondions","refondiez","refondaient"),
													array("refondis","refondis","refondit","refond�mes","refond�tes","refondirent"),
													array("refondis","refondis","refondit","refond�mes","refond�tes","refondirent"),
													array("refondrais","refondrais","refondrait","refondrions","refondriez","refondraient")
												),				
								"refendre"=> array(
													array("refends","refends","refend","refendons","refendez","refendent"),
													array("refendu","refendu","refendu","refendu","refendu","refendu"),
													array("refendais","refendais","refendait","refendions","refendiez","refendaient"),
													array("refendis","refendis","refendit","refend�mes","refend�tes","refendirent"),
													array("refendis","refendis","refendit","refend�mes","refend�tes","refendirent"),
													array("refendrais","refendrais","refendrait","refendrions","refendriez","refendraient")
												),	
								"rejoindre"=> array(
													array("rejoins","rejoins","rejoint","rejoignons","rejoignez","rejoignent"),
													array("rejoint","rejoint","rejoint","rejoint","rejoint","rejoint"),
													array("rejoignais","rejoignais","rejoignait","rejoignions","rejoigniez","rejoignaient"),
													array("rejoignis","rejoignis","rejoignit","rejoign�mes","rejoign�tes","rejoignirent"),
													array("rejoindrai","rejoindras","rejoindra","rejoindrons","rejoindrez","rejoindront"),
													array("rejoindrais","rejoindrais","rejoindrait","rejoindrions","rejoindriez","rejoindraient")
												),	
								"remettre"=> array(
													array("remets","remets","remet","remettons","remettez","remettent"),
													array("remis","remis","remis","remis","remis","remis"),
													array("remettais","remettais","remettait","remettions","remettiez","remettaient"),
													array("remis","remis","remit","rem�mes","rem�tes","remirent"),
													array("remettrai","remettras","remettra","remettrons","remettrez","remettront"),
													array("remettrais","remettrais","remettrait","remettrions","remettriez","remettraient")
												),	
								"remordre"=> array(
													array("remords","remords","remord","remordons","remordez","remordent"),
													array("remordu","remordu","remordu","remordu","remordu","remordu"),
													array("remordais","remordais","remordait","remordions","remordiez","remordaient"),
													array("remordis","remordis","remordit","remord�mes","remord�tes","remordiremort"),
													array("remordis","remordis","remordit","remord�mes","remord�tes","remordiremort"),
													array("remordrais","remordrais","remordrait","remordrions","remordriez","remordraient")
												),	
								"renaitre"=> array(
													array("renais","renais","rena�t","renaissorens","renaissez","renaisserent"),
													array("ren�","ren�","ren�","ren�","ren�","ren�"),
													array("renaissais","renaissais","renaissait","renaissiorens","renaissiez","renaissaient"),
													array("renaquis","renaquis","renaquit","renaqu�mes","renaqu�tes","naquirent"),
													array("rena�trai","rena�tras","rena�tra","rena�trorens","rena�trez","rena�tront"),
													array("rena�trais","rena�trais","rena�trait","rena�triorens","rena�triez","rena�traient")
												),	
								"r�pandre"=> array(
													array("r�pands","r�pands","r�pand","r�pandons","r�pandez","r�pandent"),
													array("r�pandu","r�pandu","r�pandu","r�pandu","r�pandu","r�pandu"),
													array("r�pandais","r�pandais","r�pandait","r�pandions","r�pandiez","r�pandaient"),
													array("r�pandis","r�pandis","r�pandit","r�pand�mes","r�pand�tes","r�pandirent"),
													array("r�pandis","r�pandis","r�pandit","r�pand�mes","r�pand�tes","r�pandirent"),
													array("r�pandrais","r�pandrais","r�pandrait","r�pandrions","r�pandriez","r�pandraient")
												),		
								"repartir"=> array(
													array("repas","repas","repart","repartons","repartez","repartent"),
													array("reparti","reparti","reparti","reparti","reparti","reparti"),
													array("repartais","repartais","repartait","repartions","repartiez","repartaient"),
													array("repartis","repartis","repartit","repart�mes","repart�tes","repartirent"),
													array("repartirai","repartiras","repartira","repartirons","repartirez","repartiront"),
													array("repartirais","repartirais","repartirait","repartirions","repartiriez","repartiraient")
												),	
								"repeindre"=> array(
													array("repeins","repeins","repeint","repeignons","repeignez","repeignent"),
													array("repeint","repeint","repeint","repeint","repeint","repeint"),
													array("repeignais","repeignais","repeignait","repeignions","repeigniez","repeignaient"),
													array("repeignis","repeignis","repeignit","repeign�mes","repeign�tes","repeignirent"),
													array("repeindrai","repeindras","repeindra","repeindrons","repeindrez","repeindront"),
													array("repeindrais","repeindrais","repeindrait","repeindrions","repeindriez","repeindraient")
												),			
								"r�partir"=> array(
													array("repas","repas","r�part","r�partons","r�partez","r�partent"),
													array("r�parti","r�parti","r�parti","r�parti","r�parti","r�parti"),
													array("r�partais","r�partais","r�partait","r�partions","r�partiez","r�partaient"),
													array("r�partis","r�partis","r�partit","r�part�mes","r�part�tes","r�partirent"),
													array("r�partirai","r�partiras","r�partira","r�partirons","r�partirez","r�partiront"),
													array("r�partirais","r�partirais","r�partirait","r�partirions","r�partiriez","r�partiraient")
												),	
								"r�pondre"=> array(
													array("r�ponds","r�ponds","r�pond","r�pondons","r�pondez","r�pondent"),
													array("r�pondu","r�pondu","r�pondu","r�pondu","r�pondu","r�pondu"),
													array("r�pondais","r�pondais","r�pondait","r�pondions","r�pondiez","r�pondaient"),
													array("r�pondis","r�pondis","r�pondit","r�pond�mes","r�pond�tes","r�pondirent"),
													array("r�pondis","r�pondis","r�pondit","r�pond�mes","r�pond�tes","r�pondirent"),
													array("r�pondrais","r�pondrais","r�pondrait","r�pondrions","r�pondriez","r�pondraient")
												),	
								"reprendre"=> array(
													array("reprends","reprends","reprend","prenons","prenez","prennent"),
													array("pris","pris","pris","pris","pris","pris"),
													array("prenais","prenais","prenait","prenions","preniez","prenaient"),
													array("pris","pris","prit","pr�mes","pr�tes","prirent"),
													array("reprendrai","reprendras","reprendra","reprendrons","reprendrez","reprendront"),
													array("reprendrais","reprendrais","reprendrait","reprendrions","reprendriez","reprendraient")
												),
								"ressentir"=> array(
													array("ressens","ressens","ressent","ressentons","ressentez","ressentent"),
													array("ressenti","ressenti","ressenti","ressenti","ressenti","ressenti"),
													array("ressentais","ressentais","ressentait","ressentions","ressentiez","ressentaient"),
													array("ressentis","ressentis","ressentit","ressent�mes","ressent�tes","ressentirent"),
													array("ressentirai","ressentiras","ressentira","ressentirons","ressentirez","ressentiront"),
													array("ressentirais","ressentirais","ressentirait","ressentirions","ressentiriez","ressentiraient")
												),					
								"ressortir"=> array(
													array("ressors","ressors","ressort","ressortons","ressortez","ressortent"),
													array("ressorti","ressorti","ressorti","ressorti","ressorti","ressorti"),
													array("ressortais","ressortais","ressortait","ressortions","ressortiez","ressortaient"),
													array("ressortis","ressortis","ressortit","ressort�mes","ressort�tes","ressortirent"),
													array("ressortirai","ressortiras","ressortira","ressortirons","ressortirez","ressortiront"),
													array("ressortirais","ressortirais","ressortirait","ressortirions","ressortiriez","ressortiraient")
												),		
								"restreindre"=> array(
													array("restreins","restreins","restreint","peignons","peignez","peignent"),
													array("restreint","restreint","restreint","restreint","restreint","restreint"),
													array("restiendrais","restiendrais","restiendrait","restiendrions","restiendriez","restiendraient"),
													array("restiendris","restiendris","restiendrit","restiendr�mes","restiendr�tes","restiendrirent"),
													array("restreindrai","restreindras","restreindra","restreindrons","restreindrez","restreindront"),
													array("restreindrais","restreindrais","restreindrait","restreindrions","restreindriez","restreindraient")
												),			
								"retenir"=> array(
													array("retiens","retiens","retienret","retenons","retenez","retiennent"),
													array("retenu","retenu","retenu","retenu","retenu","retenu"),
													array("retenais","retenais","retenairet","retenions","reteniez","retenaient"),
													array("retins","retins","retinret","ret�nmes","ret�nretes","retinrent"),
													array("retiendrai","retiendras","retiendra","retiendrons","retiendrez","retiendront"),
													array("retiendrais","retiendrais","retiendrairet","retiendrions","retiendriez","retiendraient")
												),	
								"retordre"=> array(
													array("retords","retords","retord","retordons","retordez","retordent"),
													array("retordu","retordu","retordu","retordu","retordu","retordu"),
													array("retordais","retordais","retordait","retordions","retordiez","retordaient"),
													array("retordis","retordis","retordit","retord�mes","retord�tes","retordirent"),
													array("retordis","retordis","retordit","retord�mes","retord�tes","retordirent"),
													array("retordrais","retordrais","retordrait","retordrions","retordriez","retordraient")
												),
								"tordre"=> array(
													array("tords","tords","tord","tordons","tordez","tordent"),
													array("tordu","tordu","tordu","tordu","tordu","tordu"),
													array("tordais","tordais","tordait","tordions","tordiez","tordaient"),
													array("tordis","tordis","tordit","tord�mes","tord�tes","tordirent"),
													array("tordis","tordis","tordit","tord�mes","tord�tes","tordirent"),
													array("tordrais","tordrais","tordrait","tordrions","tordriez","tordraient")
												),		
								"tordre"=> array(
													array("tords","tords","tord","tordons","tordez","tordent"),
													array("tordu","tordu","tordu","tordu","tordu","tordu"),
													array("tordais","tordais","tordait","tordions","tordiez","tordaient"),
													array("tordis","tordis","tordit","tord�mes","tord�tes","tordirent"),
													array("tordis","tordis","tordit","tord�mes","tord�tes","tordirent"),
													array("tordrais","tordrais","tordrait","tordrions","tordriez","tordraient")
												),		
								"revendre"=> array(
													array("revends","revends","revend","revendons","revendez","revendent"),
													array("revendu","revendu","revendu","revendu","revendu","revendu"),
													array("revendais","revendais","revendait","revendions","revendiez","revendaient"),
													array("revendis","revendis","revendit","revend�mes","revend�tes","revendirent"),
													array("revendis","revendis","revendit","revend�mes","revend�tes","revendirent"),
													array("revendrais","revendrais","revendrait","revendrions","revendriez","revendraient")
												),	
								"revenir"=> array(
													array("reviens","reviens","revient","revenons","revenez","reviennent"),
													array("revenu","revenu","revenu","revenus","revenus","revenus"),
													array("revenais","revenais","revenait","revenions","reveniez","revenaient"),
													array("revins","revins","revint","rev�nmes","rev�ntes","revinrent"),
													array("reviendrai","reviendras","reviendra","reviendrons","reviendrez","reviendront"),
													array("reviendrais","reviendrais","reviendrait","reviendrions","reviendriez","reviendraient")
												),				
								"rev�tir"=> array(
													array("rev�ts","rev�ts","rev�t","rev�tons","rev�tez","rev�tent"),
													array("rev�tu","rev�tu","rev�tu","rev�tu","rev�tu","rev�tu"),
													array("rev�tais","rev�tais","rev�tait","rev�tions","rev�tiez","rev�taient"),
													array("rev�tis","rev�tis","rev�tit","rev�t�mes","rev�t�tes","rev�tirent"),
													array("rev�tirai","rev�tiras","rev�tira","rev�tirons","rev�tirez","rev�tiront"),
													array("rev�tirais","rev�tirais","rev�tirait","rev�tirions","rev�tiriez","rev�tiraient")
												),			
								"vivre"=> array(
													array("vis","vis","vit","vivons","vivez","vivent"),
													array("v�cu","v�cu","v�cu","v�cu","v�cu","v�cu"),
													array("vivais","vivais","vivait","vivions","viviez","vivaient"),
													array("v�cus","v�cus","v�cut","v�c�mes","v�c�tes","v�curent"),
													array("vivrai","vivras","vivra","vivrons","vivrez","vivront"),
													array("vivrais","vivrais","vivrait","vivrions","vivriez","vivraient")
												),			
								"revivre"=> array(
													array("revis","revis","revit","revivons","revivez","revivent"),
													array("rev�cu","rev�cu","rev�cu","rev�cu","rev�cu","rev�cu"),
													array("revivais","revivais","revait","revions","reviez","revivaient"),
													array("rev�cus","rev�cus","rev�cut","rev�c�mes","rev�c�tes","rev�curent"),
													array("revivrai","revivras","revivra","revivrons","revivrez","revivront"),
													array("revivrais","revivrais","revivrait","revivrions","revivriez","revivraient")
												),	
								"revoir"=> array(
													array("revois","revois","revoit","revoyons","revoyez","revoient"),
													array("revu","revu","revu","revu","revu","revu"),
													array("revoyais","revoyais","revoyait","revoyions","revoyiez","revoyaient"),
													array("revis","revis","revit","rev�mes","rev�tes","revirent"),
													array("reverrai","reverras","reverra","reverrons","reverrez","reverront"),
													array("reverrais","reverrais","reverrait","reverrions","reverriez","reverraient")
												),		
	
								"revouloir"=> array(
													array("reveux","reveux","reveut","revoulons","revoulez","reveulent"),
													array("revoulu","revoulu","revoulu","revoulu","revoulu","revoulu"),
													array("revoulais","revoulais","revoulait","revoulions","revouliez","revoulaient"),
													array("revoulus","revoulus","revoulut","revoul�mes","revoul�tes","revoulurent"),
													array("revoudrai","revoudras","revoudra","revoudrons","revoudrez","revoudront"),
													array("revoudrais","revoudrais","revoudrait","revoudrions","revoudriez","revoudraient")
												),	
								"rire"=> array(
													array("ris","ris","rit","rions","riez","rient"),
													array("ri","ri","ri","ri","ri","ri"),
													array("riais","riais","riait","riions","riiez","riaient"),
													array("ris","ris","rit","r�mes","r�tes","rirent"),
													array("rirai","riras","rira","rirons","rirez","riront"),
													array("rirais","rirais","rirait","ririons","ririez","riraient")
												),		
								"rompre"=> array(
													array("romps","romps","romp","rompons","rompez","rompent"),
													array("rompu","rompu","rompu","rompu","rompu","rompu"),
													array("rompais","rompais","rompait","rompions","rompiez","rompaient"),
													array("rompis","rompis","rompit","romp�mes","romp�tes","rompirent"),
													array("rompis","rompis","rompit","romp�mes","romp�tes","rompirent"),
													array("romprais","romprais","romprait","romprions","rompriez","rompraient")
												),	
								"savoir"=> array(
													array("sais","sais","sait","savons","savez","savent"),
													array("su","su","su","su","su","su"),
													array("savais","savais","savait","savions","saviez","savaient"),
													array("sus","sus","sut","s�mes","s�tes","surent"),
													array("saurai","sauras","saura","saurons","saurez","sauront"),
													array("saurais","saurais","saurait","saurions","sauriez","sauraient")
												),
								"sentir"=> array(
													array("sens","sens","sent","sentons","sentez","sentent"),
													array("senti","senti","senti","senti","senti","senti"),
													array("sentais","sentais","sentait","sentions","sentiez","sentaient"),
													array("sentis","sentis","sentit","sent�mes","sent�tes","sentirent"),
													array("sentirai","sentiras","sentira","sentirons","sentirez","sentiront"),
													array("sentirais","sentirais","sentirait","sentirions","sentiriez","sentiraient")
												),		
								"ressentir"=> array(
													array("ressens","ressens","ressent","ressentons","ressentez","ressentent"),
													array("ressenti","ressenti","ressenti","ressenti","ressenti","ressenti"),
													array("ressentais","ressentais","ressentait","ressentions","ressentiez","ressentaient"),
													array("ressentis","ressentis","ressentit","ressent�mes","ressent�tes","ressentirent"),
													array("ressentirai","ressentiras","ressentira","ressentirons","ressentirez","ressentiront"),
													array("ressentirais","ressentirais","ressentirait","ressentirions","ressentiriez","ressentiraient")
												),	
												
								"servir"=> array(
													array("sers","sers","sert","servons","servez","servent"),
													array("servi","servi","servi","servi","servi","servi"),
													array("servais","servais","servait","servions","serviez","servaient"),
													array("servis","servis","servit","serv�mes","serv�tes","servirent"),
													array("servirai","serviras","servira","servirons","servirez","serviront"),
													array("servirais","servirais","servirait","servirions","serviriez","serviraient")
												),
								"sortir"=> array(
													array("sors","sors","sort","sortons","sortez","sortent"),
													array("sorti","sorti","sorti","sorti","sorti","sorti"),
													array("sortais","sortais","sortait","sortions","sortiez","sortaient"),
													array("sortis","sortis","sortit","sort�mes","sort�tes","sortirent"),
													array("sortirai","sortiras","sortira","sortirons","sortirez","sortiront"),
													array("sortirais","sortirais","sortirait","sortirions","sortiriez","sortiraient")
												),	
								"soumettre"=> array(
													array("soumets","soumets","soumet","soumettons","soumettez","soumettent"),
													array("soumis","soumis","soumis","soumis","soumis","soumis"),
													array("soumettais","soumettais","soumettait","soumettions","soumettiez","soumettaient"),
													array("soumis","soumis","soumit","soum�mes","soum�tes","soumirent"),
													array("soumettrai","soumettras","soumettra","soumettrons","soumettrez","soumettront"),
													array("soumettrais","soumettrais","soumettrait","soumettrions","soumettriez","soumettraient")
												),								
								"sourire"=> array(
													array("souris","souris","sourit","sourions","souriez","sourient"),
													array("souri","souri","souri","souri","souri","souri"),
													array("souriais","souriais","souriait","souriions","souriiez","souriaient"),
													array("souris","souris","sourit","r�mes","r�tes","sourirent"),
													array("sourirai","souriras","sourira","sourirons","sourirez","souriront"),
													array("sourirais","sourirais","sourirait","souririons","souririez","souriraient")
												),							
								"traire"=> array(
													array("trais","trais","trait","trayons","trayez","traient"),
													array("trait","trait","trait","trait","trait","trait"),
													array("trayais","trayais","trayait","trayions","trayiez","trayaient"),
													array("trairai","trairas","traira","trairons","trairez","trairont"),
													array("trairai","trairas","traira","trairons","trairez","trairont"),
													array("trairais","trairais","trairait","trairions","trairiez","trairaient")									
												),
								"soustraire"=> array(
													array("soustrais","soustrais","soustrait","soustrayons","soustrayez","soustraient"),
													array("soustrait","soustrait","soustrait","soustrait","soustrait","soustrait"),
													array("soustrayais","soustrayais","soustrayait","soustrayions","soustrayiez","soustrayaient"),
													array("soustrairai","soustrairas","soustraira","soustrairons","soustrairez","soustrairont"),
													array("soustrairai","soustrairas","soustraira","soustrairons","soustrairez","soustrairont"),
													array("soustrairais","soustrairais","soustrairait","soustrairions","soustrairiez","soustrairaient")									
												),
								"soutenir"=> array(
													array("soutiens","soutiens","soutient","soutenons","soutenez","soutiennent"),
													array("soutenu","soutenu","soutenu","soutenu","soutenu","soutenu"),
													array("soutenais","soutenais","soutenait","soutenions","souteniez","soutenaient"),
													array("soutins","soutins","soutint","sout�nmes","sout�ntes","soutinrent"),
													array("soutiendrai","soutiendras","soutiendra","soutiendrons","soutiendrez","soutiendront"),
													array("soutiendrais","soutiendrais","soutiendrait","soutiendrions","soutiendriez","soutiendraient")
												),
								"souvenir"=> array(
													array("souviens","souviens","souvient","souvenons","souvenez","souviennent"),
													array("souvenu","souvenu","souvenu","souvenu","souvenu","souvenu"),
													array("souvenais","souvenais","souvenait","souvenions","souveniez","souvenaient"),
													array("souvins","souvins","souvint","souv�nmes","souv�ntes","souvinrent"),
													array("souviendrai","souviendras","souviendra","souviendrons","souviendrez","souviendront"),
													array("souviendrais","souviendrais","souviendrait","souviendrions","souviendriez","souviendraient")
												),		
								"suivre"=> array(
													array("suis","suis","suit","suivons","suivez","suivent"),
													array("suivi","suivi","suivi","suivi","suivi","suivi"),
													array("suivais","suivais","suivait","suivions","suiviez","suivaient"),
													array("suivis","suivis","suivit","suiv�mes","suiv�tes","suivirent"),
													array("suivrai","suivras","suivra","suivrons","suivrez","suivront"),
													array("suivrais","suivrais","suivrait","suivrions","suivriez","suivraient")
												),
								"subvenir"=> array(
													array("subviens","subviens","subvient","subvenons","subvenez","subviennent"),
													array("subvenu","subvenu","subvenu","subvenus","subvenus","subvenus"),
													array("subvenais","subvenais","subvenait","subvenions","subveniez","subvenaient"),
													array("subvins","subvins","subvint","subv�nmes","subv�ntes","subvinrent"),
													array("subviendrai","subviendras","subviendra","subviendrons","subviendrez","subviendront"),
													array("subviendrais","subviendrais","subviendrait","subviendrions","subviendriez","subviendraient")
												),
								"surprendre"=> array(
													array("surprends","surprends","surprend","surprenons","surprenez","surprennent"),
													array("surpris","surpris","surpris","surpris","surpris","surpris"),
													array("surprenais","surprenais","surprenait","surprenions","surpreniez","surprenaient"),
													array("surpris","surpris","surprit","surpr�mes","surpr�tes","surprirent"),
													array("surprendrai","surprendras","surprendra","surprendrons","surprendrez","surprendront"),
													array("surprendrais","surprendrais","surprendrait","surprendrions","surprendriez","surprendraient")
												),	
								"survenir"=> array(
													array("surviens","surviens","survient","survenons","survenez","surviennent"),
													array("survenu","survenu","survenu","survenus","survenus","survenus"),
													array("survenais","survenais","survenait","survenions","surveniez","survenaient"),
													array("survins","survins","survint","surv�nmes","surv�ntes","survinrent"),
													array("surviendrai","surviendras","surviendra","surviendrons","surviendrez","surviendront"),
													array("surviendrais","surviendrais","surviendrait","surviendrions","surviendriez","surviendraient")
												),
								"survivre"=> array(
													array("survis","survis","survit","survivons","survivez","survivent"),
													array("surv�cu","surv�cu","surv�cu","surv�cu","surv�cu","surv�cu"),
													array("survivais","survivais","survivait","survivions","surviviez","survivaient"),
													array("surv�cus","surv�cus","surv�cut","surv�c�mes","surv�c�tes","surv�curent"),
													array("survivrai","survivras","survivra","survivrons","survivrez","survivront"),
													array("survivrais","survivrais","survivrait","survivrions","survivriez","survivraient")
												),	
								"susprendre"=> array(
													array("susprends","susprends","susprend","susprenons","susprenez","susprennent"),
													array("suspris","suspris","suspris","suspris","suspris","suspris"),
													array("susprenais","susprenais","susprenait","susprenions","suspreniez","susprenaient"),
													array("suspris","suspris","susprit","suspr�mes","suspr�tes","susprirent"),
													array("susprendrai","susprendras","susprendra","susprendrons","susprendrez","susprendront"),
													array("susprendrais","susprendrais","susprendrait","susprendrions","susprendriez","susprendraient")
												),
								"taire"=> array(
													array("tais","tais","ta�t","taisons","taisez","taisent"),
													array("tu","tu","tu","tu","tu","tu"),
													array("taisais","taisais","taisait","taisions","taisiez","taisaient"),
													array("tus","tus","tut","t�mes","t�tes","turent"),
													array("tairai","tairas","taira","tairons","tairez","tairont"),
													array("tairais","tairais","tairait","tairions","tairiez","tairaient")
												),			
								"teindre"=> array(
													array("teins","teins","teint","teignons","teignez","teignent"),
													array("teint","teint","teint","teint","teint","teint"),
													array("teignais","teignais","teignait","teignions","teigniez","teignaient"),
													array("teignis","teignis","teignit","teign�mes","teign�tes","teignirent"),
													array("teindrai","teindras","teindra","teindrons","teindrez","teindront"),
													array("teindrais","teindrais","teindrait","teindrions","teindriez","teindraient")
												),	
								"tenir"=> array(
													array("tiens","tiens","tient","tenons","tenez","tiennent"),
													array("tenu","tenu","tenu","tenu","tenu","tenu"),
													array("tenais","tenais","tenait","tenions","teniez","tenaient"),
													array("tins","tins","tint","t�nmes","t�ntes","tinrent"),
													array("tiendrai","tiendras","tiendra","tiendrons","tiendrez","tiendront"),
													array("tiendrais","tiendrais","tiendrait","tiendrions","tiendriez","tiendraient")
												),				
								"tendre"=> array(
													array("tends","tends","tend","tendons","tendez","tendent"),
													array("tendu","tendu","tendu","tendu","tendu","tendu"),
													array("tendais","tendais","tendait","tendions","tendiez","tendaient"),
													array("tendis","tendis","tendit","tend�mes","tend�tes","tendirent"),
													array("tendrai","tendras","tendra","tendrons","tendrez","tendront"),
													array("tendrais","tendrais","tendrait","tendrions","tendriez","tendraient")
												),		
								"tondre"=> array(
													array("tonds","tonds","tond","tondons","tondez","tondent"),
													array("tondu","tondu","tondu","tondu","tondu","tondu"),
													array("tondais","tondais","tondait","tondions","tondiez","tondaient"),
													array("tondis","tondis","tondit","tond�mes","tond�tes","tondirent"),
													array("tondis","tondis","tondit","tond�mes","tond�tes","tondirent"),
													array("tondrais","tondrais","tondrait","tondrions","tondriez","tondraient")
												),
								"tordre"=> array(
													array("tords","tords","tord","tordons","tordez","tordent"),
													array("tordu","tordu","tordu","tordu","tordu","tordu"),
													array("tordais","tordais","tordait","tordions","tordiez","tordaient"),
													array("tordis","tordis","tordit","tord�mes","tord�tes","tordirent"),
													array("tordis","tordis","tordit","tord�mes","tord�tes","tordirent"),
													array("tordrais","tordrais","tordrait","tordrions","tordriez","tordraient")
												),		
								"transmettre"=> array(
													array("transmets","transmets","transmet","transmettons","transmettez","transmettent"),
													array("transmis","transmis","transmis","transmis","transmis","transmis"),
													array("transmettais","transmettais","transmettait","transmettions","transmettiez","transmettaient"),
													array("transmis","transmis","transmit","transm�mes","transm�tes","transmirent"),
													array("transmettrai","transmettras","transmettra","transmettrons","transmettrez","transmettront"),
													array("transmettrais","transmettrais","transmettrait","transmettrions","transmettriez","transmettraient")
												),		
								"transparaitre"=> array(
													array("transparais","transparais","transpara�t","transparaissons","transparaissez","transparaissent"),
													array("transparu","transparu","transparu","transparu","transparu","transparu"),
													array("transparaissais","transparaissais","transparaissait","transparaissions","transparaissiez","transparaissaient"),
													array("transparus","transparus","transparut","transpar�mes","transpar�tes","transparurent"),
													array("transpara�trai","transpara�tras","transpara�tra","transpara�trons","transpara�trez","transpara�tront"),
													array("transpara�trais","transpara�trais","transpara�trait","transpara�trions","transpara�triez","transpara�traient")
												),	
								"vaincre"=> array(
													array("vaincs","vaincs","vainc","vainquons","vainquez","vainquent"),
													array("vaincu","vaincu","vaincu","vaincu","vaincu","vaincu"),
													array("vainquais","vainquais","vainquait","vainquions","vainquiez","vainquaient"),
													array("vainquis","vainquis","vainquit","vainqu�mes","vainqu�tes","vainquirent"),
													array("vaincrai","vaincras","vaincra","vaincrons","vaincrez","vaincront"),
													array("vaincrais,vaincrais","vaincrait","vaincrions","vaincriez","vaincraient")
												),			
								"valoir"=> array(
													array("vaux","vaux","vaut","valons","valez","valent"),
													array("valu","valu","valu","valu","valu","valu"),
													array("valais","valais","valait","valions","valiez","valaient"),
													array("valus","valus","valut","val�mes","val�tes","valurent"),
													array("vaudrai","vaudras","vaudra","vaudrons","vaudrez","vaudront"),
													array("vaudrais","vaudrais","vaudrait","vaudrions","vaudriez","vaudraient")
												),	
								"vendre"=> array(
													array("vends","vends","vend","vendons","vendez","vendent"),
													array("vendu","vendu","vendu","vendu","vendu","vendu"),
													array("vendais","vendais","vendait","vendions","vendiez","vendaient"),
													array("vendis","vendis","vendit","vend�mes","vend�tes","vendirent"),
													array("vendis","vendis","vendit","vend�mes","vend�tes","vendirent"),
													array("vendrais","vendrais","vendrait","vendrions","vendriez","vendraient")
												),	
								"v�tir"=> array(
													array("v�ts","v�ts","v�t","v�tons","v�tez","v�tent"),
													array("v�tu","v�tu","v�tu","v�tu","v�tu","v�tu"),
													array("v�tais","v�tais","v�tait","v�tions","v�tiez","v�taient"),
													array("v�tis","v�tis","v�tit","v�t�mes","v�t�tes","v�tirent"),
													array("v�tirai","v�tiras","v�tira","v�tirons","v�tirez","v�tiront"),
													array("v�tirais","v�tirais","v�tirait","v�tirions","v�tiriez","v�tiraient")
												),		
								"voir"=> array(
													array("vois","vois","voit","voyons","voyez","voient"),
													array("vu","vu","vu","vu","vu","vu"),
													array("voyais","voyais","voyait","voyions","voyiez","voyaient"),
													array("vis","vis","vit","v�mes","v�tes","virent"),
													array("verrai","verras","verra","verrons","verrez","verront"),
													array("verrais","verrais","verrait","verrions","verriez","verraient")
												),													
								"vouloir"=> array(
													array("veux","veux","veut","voulons","voulez","veulent"),
													array("voulu","voulu","voulu","voulu","voulu","voulu"),
													array("voulais","voulais","voulait","voulions","vouliez","voulaient"),
													array("voulus","voulus","voulut","voul�mes","voul�tes","voulurent"),
													array("voudrai","voudras","voudra","voudrons","voudrez","voudront"),
													array("voudrais","voudrais","voudrait","voudrions","voudriez","voudraient")
												)											
								);
								
?>