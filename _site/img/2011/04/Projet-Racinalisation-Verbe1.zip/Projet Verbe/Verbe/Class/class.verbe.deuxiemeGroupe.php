<?php


/*
*
* 	Sarcy Romain
* 	Date de cr�ation: 30/03/11
*	Cette classe permet de trouver la conjugaison des verbes du 2e groupe
*
*
*/



class verbeDeuxiemeGroupe
{
	private $listeVerbeDeuxiemeGroupe;
	
	
	public function __construct($listeVerbe = null)
	{
		if(!(is_null($listeVerbe)))
		{
			$this->listeVerbeDeuxiemeGroupe = $listeVerbe;
		}
	}
	
	 public function setListeVerbe($listeVerbe)
	{
		$this->listeVerbeDeuxiemeGroupe = $listeVerbe;
	}
	
	public function getListeVerbeConjugue()
	{
		foreach ($this->listeVerbeDeuxiemeGroupe as $verbe)
		{
			$listeVerbeConjugue[$verbe] = $this->construireConjugaison($verbe);
		}
		return $listeVerbeConjugue;
	}

	
	// classe permettant de construire toute la conjugaison d'un verbe
	public function construireConjugaison($verbe)
		{
			$pI = $this->presentIndicatif($verbe);
			$f = $this->futur($verbe);
			$pS = $this->passeSimple($verbe);
			$i = $this->imparfait($verbe);
			$passeC = $this->passeCompose($verbe);
			$presentC = $this->presentConditionnel($verbe);
			$tabConjugaison = array( $pI, $f, $pS, $i, $passeC, $presentC);
			
			return $tabConjugaison; 
		}
	
	// classe permettant d'enlever l'infinitif d'un verbe afin de garder le radical
	public function enleveInfinitif($verbe)
	{
		// exemple : $verbe = finir
		
		$a = substr($verbe,0,-2);
		$tabVerbe = array($a);
		
		// deviens $verbe = fin
		
		return $tabVerbe;
	}
	
	
	//classe permettant de conjuguer au pr�sent de l'indicatif	
	public function presentIndicatif($verbe)
	{
		$tabVerbe = $this->enleveInfinitif($verbe);
		
		//(je)finis;(tu)finis;(il/elle/on)finit;(nous)finissons;(vous)finissez;(ils/elles/ont)finissent;
		
		$conjugaison = array( $tabVerbe[0]."is", $tabVerbe[0]."is", $tabVerbe[0]."it", $tabVerbe[0]."issons", $tabVerbe[0]."issez",$tabVerbe[0]."issent");
		
		return $conjugaison;
	}
	


//classe permettant de conjuguer au futur
	public function futur($verbe)
	{
		$tabVerbe = $this->enleveInfinitif($verbe);
	
		$conjugaison = array( $tabVerbe[0]."irai", $tabVerbe[0]."iras", $tabVerbe[0]."ira", $tabVerbe[0]."irons", $tabVerbe[0]."irez",$tabVerbe[0]."iront");
		
		return $conjugaison;
	}
	
//classe permettant de conjuguer a l'imparfait
	public function imparfait($verbe)
	{
		$tabVerbe = $this->enleveInfinitif($verbe);
	
		$conjugaison = array( $tabVerbe[0]."issais", $tabVerbe[0]."issais", $tabVerbe[0]."issait", $tabVerbe[0]."issions", $tabVerbe[0]."issiez",$tabVerbe[0]."issaient");
		
		return $conjugaison;
	}
//classe permettant de conjuguer au passe compose	
	public function passeCompose($verbe)
	{
		$tabVerbe = $this->enleveInfinitif($verbe);
	
		$conjugaison = array( $tabVerbe[0]."i", $tabVerbe[0]."i", $tabVerbe[0]."i", $tabVerbe[0]."i", $tabVerbe[0]."i",$tabVerbe[0]."i");
		
		return $conjugaison;
	}
	
//classe permettant de conjuguer au passe simple	
	public function passeSimple($verbe)
	{
		$tabVerbe = $this->enleveInfinitif($verbe);
	
		$conjugaison = array( $tabVerbe[0]."is", $tabVerbe[0]."is", $tabVerbe[0]."it", $tabVerbe[0]."imes", $tabVerbe[0]."ites",$tabVerbe[0]."irent");
		
		return $conjugaison;
	}
	
	
	
//classe permettant de conjuguer au conditionnel pr�sent
	
	public function presentConditionnel($verbe)
	{
		$tabVerbe = $this->enleveInfinitif($verbe);
	
		$conjugaison = array( $tabVerbe[0]."irais", $tabVerbe[0]."irais", $tabVerbe[0]."irait", $tabVerbe[0]."irions", $tabVerbe[0]."iriez",$tabVerbe[0]."iraient");
		
		return $conjugaison;
	}
}	
	
	
?>
	