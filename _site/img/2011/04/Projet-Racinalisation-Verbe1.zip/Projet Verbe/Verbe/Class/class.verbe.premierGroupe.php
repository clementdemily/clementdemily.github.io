<?php

/*
*	@Auteur : DEMILY Cl�ment
*	@Date	: 30/03/2011
*
*	Cette classe g�re la conjugaison des verbes r�guli� du premier groupe.
*
*/

class verbePremierGroupe
{
	private $listeVerbePremierGroupe;

	// Constructeur 	
	public function __construct($listeVerbePremierGroupe = null)
	{
		if(!(is_null($listeVerbePremierGroupe)))
		{
			$this->listeVerbePremierGroupe = $listeVerbePremierGroupe;
		}
	}
	
	// Cette m�thode sert a affecter une liste de verbe
		public function setListeVerbe($listeVerbePremierGroupe)
	{
		$this->$listeVerbePremierGroupe = $listeVerbePremierGroupe;
	}
	
	// Cette m�thode sert a retourn� un tableau de verbes conjugu�s
	public function getListeVerbeConjugue()
	{
		foreach ($this->listeVerbePremierGroupe as $verbe)
		{
			$listeVerbeConjugue[$verbe] = $this->construireConjugaison($verbe);
		}
		return $listeVerbeConjugue;
	}
	
	// Cette m�thode construit une conjuguaison pour un verbe donn� en param�tre
	public function construireConjugaison($verbe)
	{
		$pI = $this->presentIndicatif($verbe);
		$f = $this->futur($verbe);
		$pS = $this->passeSimple($verbe);
		$i = $this->imparfait($verbe);
		$passeC = $this->passeCompose($verbe);
		$presentC = $this->presentConditionnel($verbe);
		$tabConjugaison = array( $pI, $f, $pS, $i, $passeC, $presentC);
		
		return $tabConjugaison; 
	}
	
	// Cette m�thode enl�ve les trois derni�res lettre et les stocke dans un tableau.
	public function enleverInfinitif($verbe)
	{
		// exemple : $verbe = regarder
		$a = substr($verbe,0,-1);
		$b = substr($verbe,0,-2);
		$c = substr($verbe, -3,-2);
		
		$tabVerbe = array($a, $b, $c);
		//deviens (regarde ,regard, d)
	
		return $tabVerbe;
	}
	
	// Cette m�thode d�termine si la derni�re lettre 
	public function voyelleConsonne(&$tabVerbe)
	{
		//exemple : manger => mangeais � l'imparfait
		//test si la derni�re lettre avant la terminaison de l'infinitif (ici "g") est une voyelle.

		if($tabVerbe[2] == "g")
		{
			$tabVerbe[1] .= "e";
			return true;
		}
		else 
			return false;
	}
	
	public function presentIndicatif($verbe)
	{
		$tabVerbe = $this->enleverInfinitif($verbe);
		
		//(je)regarde;(tu)regardes;(il/elle/on)regarde;
		//(nous)regardons;(vous)regardez;(ils/elles/ont)regardent;
		$terminaisons = array('', 's', '', 'ons', 'ez', 'ent');
		$conjugaison = array( $tabVerbe[0].$terminaisons[0], $tabVerbe[0].$terminaisons[1], 
								$tabVerbe[0].$terminaisons[2], $tabVerbe[1].$terminaisons[3],
								$tabVerbe[1].$terminaisons[4], $tabVerbe[1].$terminaisons[5]);
		
		if(substr($conjugaison[3], -4,-3) == 'g')
			$conjugaison[3] = $tabVerbe[0].$terminaisons[3];
		
		return $conjugaison;
	}
	
	public function futur($verbe)
	{
		$tabVerbe = $this->enleverInfinitif($verbe);
		$this->voyelleConsonne($tabVerbe);
		
		//(je)regardai;(tu)regardais;(il/elle/on)regardai;
		//(nous)regarderons;(vous)regarderez;(ils/elles/ont)regarderont;
		$terminaisons = array( 'rai', 'ras', 'ra', 'rons', 'rez', 'ront');
		$conjugaison = array( $tabVerbe[0].$terminaisons[0], $tabVerbe[0].$terminaisons[1], 
								$tabVerbe[0].$terminaisons[2], $tabVerbe[0].$terminaisons[3], 
								$tabVerbe[0].$terminaisons[4],$tabVerbe[0].$terminaisons[5]);
		
		return $conjugaison;
	}
	
	public function passeSimple($verbe)
	{
		$tabVerbe = $this->enleverInfinitif($verbe);
		$this->voyelleConsonne($tabVerbe);
		
		//(je)regardai;(tu)regardas;(il/elle/on)regarda;
		//(nous)regard�mes;(vous)regard�tes;(ils/elles/ont)regard�rent;
		$terminaisons = array('ai', 'as', 'a', '�mes', '�tes', '�rent');
		$conjugaison = array( $tabVerbe[1].$terminaisons[0], $tabVerbe[1].$terminaisons[1], 
								$tabVerbe[1].$terminaisons[2], $tabVerbe[1].$terminaisons[3], 
								$tabVerbe[1].$terminaisons[4],$tabVerbe[1].$terminaisons[5]);
		
		if(substr($conjugaison[5],-6,-5) == 'e')
		{
			$tabVerbe[0] = substr($tabVerbe[1],0,-1);
			$conjugaison[5] = $tabVerbe[0].$terminaisons[5];
		}
		return $conjugaison;
	}
	
	public function imparfait($verbe)
	{
		$tabVerbe = $this->enleverInfinitif($verbe);
		//$this->voyelleConsonne($tabVerbe);
		
		//(je)regardais;(tu)regardais;(il/elle/on)regardait;
		//(nous)regardions;(vous)regardiez;(ils/elles/ont)regardaient;
		$terminaisons = array( 'ais', 'ais', 'ait', 'ions', 'iez', 'aient');
		
		$conjugaison = array( $tabVerbe[0].$terminaisons[0], $tabVerbe[0].$terminaisons[1], 
								$tabVerbe[0].$terminaisons[2],$tabVerbe[0].$terminaisons[3], 
								$tabVerbe[0].$terminaisons[4],$tabVerbe[0].$terminaisons[5]);
										
		return $conjugaison;
	}
	
	public function passeCompose($verbe)
	{
		$tabVerbe = $this->enleverInfinitif($verbe);
		
		//(j'ai)regard�;(tu as)regard�;(il/elle/on)regard�;
		//(nous avons)regard�;(vous avez)regard�;(ils/elles ont)regard�;
		$terminaisons = '�';
		$conjugaison = array( $tabVerbe[1].$terminaisons , $tabVerbe[1].$terminaisons ,
								$tabVerbe[1].$terminaisons ,$tabVerbe[1].$terminaisons , 
								$tabVerbe[1].$terminaisons ,$tabVerbe[1].$terminaisons );
		
		return $conjugaison;
	}
	
	public function presentConditionnel($verbe)
	{
		$tabVerbe = $this->enleverInfinitif($verbe);
		$this->voyelleConsonne($tabVerbe);
		
		//(je)regardais;(tu)regardais;(il/elle/on)regardait;
		//(nous)regarderions;(vous)regarderiez;(ils/elles)regarderaient;
		
		$terminaisons = array('ais','ais','ait','erions','eriez','eraient');
		
		$conjugaison = array( $tabVerbe[1].$terminaisons[0], $tabVerbe[1].$terminaisons[1],
								$tabVerbe[1].$terminaisons[2],$tabVerbe[1].$terminaisons[3],
								 $tabVerbe[1].$terminaisons[4],$tabVerbe[0].$terminaisons[5]);
				
				
		$tabVerbe[0] = substr($tabVerbe[0],0,-1);
			if(substr($conjugaison[3],-7,-6) == "e")
				$conjugaison[3]=$tabVerbe[0].$terminaisons[3];
			if(substr($conjugaison[4],-5,-4) == "e")
				$conjugaison[4]=$tabVerbe[0].$terminaisons[4];
			if(substr($conjugaison[5],-7,-6) == "e")
				$conjugaison[5]=$tabVerbe[0].$terminaisons[5];
				
		return $conjugaison;
	}
	
	
}
?>