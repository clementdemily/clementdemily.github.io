<?php

	require_once ("listeVerbeTroisiemeGroupe.php");

	$i=0;
	echo '$listeVerbeTroisiemeGroupe = array(<br/>';	
	foreach($listeVerbeTroisiemeGroupe as $key=>$val)
	{	
		if($i%8 == 0)
			echo "<br/>";
		echo ",\"$key\"";
		$i++;
	}

?>