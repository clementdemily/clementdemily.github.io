<?php

/*
*	@Auteur : DEMILY Cl�ment, SARCY Romain
*	@Date	: 31/03/11
*/

//Contient le dictionnaire des verbes du 1er groupe.
require_once("listeVerbePremierGroupe.php");

//Contient le dictionnaire des verbes du 2�me groupe.
require_once("listeVerbeDeuxiemeGroupe.php");

//Contient le dictionnaire des verbes du 3�me groupe.
require_once("listeVerbeTroisiemeGroupe.php");


$listeVerbe = array(	
						"premierGroupe" 	=> $listeVerbePremierGroupe,
						"deuxiemeGroupe" 	=> $listeVerbeDeuxiemeGroupe,
						"troisiemeGroupe"	=> $listeVerbeTroisiemeGroupe
					);

// var_dump($listeVerbe);

?>