<?php

/*
*	@Auteur : DEMILY Cl�ment, SARCY Romain
*	@Date	: 31/03/11
*/

require_once "List/listeVerbe.php";

require_once "Class/class.verbe.premierGroupe.php";
require_once "Class/class.verbe.deuxiemeGroupe.php";
require_once "Class/class.verbe.troisiemeGroupe.php";

class verbe
{
	//Contient la liste des verbes � l'infinitif des 3 groupes
	private $listeVerbe;
	
	//Vas contenir la liste des verbes conjugu�s des 3 groupes
	private $listeVerbeConjugue;
	
	//Contient la liste des verbes conjugu� du premier groupe
	private $listeVerbeConjuguePremierGroupe;
	
	//Contient la liste des verbes conjugu� du deuxi�me groupe
	private $listeVerbeConjugueDeuxiemeGroupe;
	
	//Contient la liste des verbes conjugu� du troisieme groupe
	private $listeVerbeConjugueTroisiemeGroupe;
	
	
	public function __construct($listeVerbe)
	{
		$this->listeVerbe = $listeVerbe;
		$this->listeVerbeConjuguePremierGroupe  = new verbePremierGroupe($this->listeVerbe["premierGroupe"]);
		$this->listeVerbeConjugueDeuxiemeGroupe = new verbeDeuxiemeGroupe($this->listeVerbe["deuxiemeGroupe"]);
		$this->listeVerbeConjugueTroisiemeGroupe = new verbeTroisiemeGroupe($this->listeVerbe["troisiemeGroupe"]);
	
					//[groupe][verbe][temps][terminaison]
		//$listeVerbeConjugue[0][0][0][0]
		$this->listeVerbeConjugue["premierGroupe"] = $this->listeVerbeConjuguePremierGroupe->getListeVerbeConjugue();
		$this->listeVerbeConjugue["deuxiemeGroupe"] = $this->listeVerbeConjugueDeuxiemeGroupe->getListeVerbeConjugue();
		$this->listeVerbeConjugue["troisiemeGroupe"] = $this->listeVerbeConjugueTroisiemeGroupe->getListeVerbeConjugue();
	}

	public function getListeVerbeConjugue()
	{
		if(!empty($this->listeVerbeConjugue))
			return $this->listeVerbeConjugue;
		else 
			return false;
	}
	
	public function getInfinitif($verbe)
	{
		$verbeRaciniser = $this->rechercherGroupe($verbe);
		return $verbeRaciniser;
	}
	
	public function rechercherGroupe($verbe)
	{
		$verbeRaciniser = $this->parcourirTableau($verbe);
		return $verbeRaciniser;
	}
	
	public function parcourirTableau($verbeConjugue)
	{
			// 3 groupe : [0] => 1er Grp, [1] => 2�me Grp, [3]=> 3�me Grp.
		foreach($this->listeVerbeConjugue as $groupe=>$verbe)
		{
		
			//$groupe => cl� => 1er grp, 2�me grp, 3�me grp.
			//$verbe['manger'] => tableau de temps
			foreach($verbe as $nomDuVerbe=>$temps)
			{	
				if($nomDuVerbe == $verbeConjugue)
					return $nomDuVerbe;
				//$nomDuVerbe c'est le nom du verbe (cl� du tableau "$verbe")
				//temps['0'] => c'est le premier temps (pr�sent)
				foreach($temps as $key=>$terminaison)
				{
					
					// echo "groupe: $groupe | verbe: $verbe <br/>";
					// echo "nomDuVerbe: $nomDuVerbe | temps: $temps <br/>";
					// echo "key: $key | terminaison : $terminaison <br/>";
					
					//$key => 0 => pr�sent
					//terminaison => .....
					//terminaison[0], terminaison[1], terminaison[2]...
					for($i = 0 ; $i < count($terminaison); $i++)
					{
						// echo "terminsaison : $terminaison[$i]";
						// echo "<br/>";
						$resultat = $this->comparaison($verbeConjugue,$terminaison[$i]);
						if($resultat == true)
							return $nomDuVerbe;
					}
				}
			}
		}
			return false;
	}
	
	public function comparaison($verbeConjugue, $terminaison)
	{
		if($verbeConjugue == $terminaison)
			return true;
		
		else
			return false;
	}



}





?>