<?php
/*
*	@Auteur : DEMILY Cl�ment, SARCY Romain
*	@Date	: 30/03/2011
*
*	Cette classe g�re la conjugaison des verbes irr�guli�s et celle du troisi�me groupe.
*
*/


class verbeTroisiemeGroupe
{
	private $listeVerbeTroisiemeGroupe;
	
	// Constructeur 	
	public function __construct($listeVerbeTroisiemeGroupe = null)
	{
		if(!(is_null($listeVerbeTroisiemeGroupe)))
		{
			$this->listeVerbeTroisiemeGroupe = $listeVerbeTroisiemeGroupe;
		}
	}
	
	// Cette m�thode sert a affecter une liste de verbe
	public function setListeVerbe($listeVerbeTroisiemeGroupe)
	{
		$this->$listeVerbeTroisiemeGroupe = $listeVerbeTroisiemeGroupe;
	}
	
	public function getListeVerbeConjugue()
	{
		return $this->listeVerbeTroisiemeGroupe;
	}
}
?>